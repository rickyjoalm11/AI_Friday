# Device AI Companion

A small Windows desktop app that monitors your PC (CPU, RAM, disk, battery), spots two kinds of problems
(low disk space, sustained high memory), and talks you through a fix with a local AI (Ollama + Phi-4).
**Nothing is deleted or closed unless you press Approve on one specific plan.**
A one-click **Simulate issue** button demonstrates the whole flow on made-up numbers without touching your PC.

```
Electron (main process)  ── starts/stops ──►  Python FastAPI backend (127.0.0.1, random port, per-launch token)
 ├─ Dashboard window (React + Tailwind)            ├─ telemetry.py      psutil, every 60 s
 ├─ Floating chat window (draggable bubble         ├─ detection.py      the two rules
 │   → mini-chat, badge, Windows notifications)    ├─ workflow.py       issue state machine + approvals + chat
 └─ WebSocket client for notifications             ├─ remediation.py    action registry + REAL executor
                                                   ├─ simulation.py     SIMULATED executor + synthetic samples
                                                   ├─ ai_service.py     Ollama Phi-4 + offline fallback
                                                   └─ database.py       SQLite (issues, chat, audit events, real telemetry)
```

## Run it (development)

Prerequisites: Windows 10/11, Python 3.11+, Node.js 20+, optionally [Ollama](https://ollama.com).

```powershell
powershell -ExecutionPolicy Bypass -File scripts\setup_dev.ps1     # venv + pip + npm install
ollama pull phi4                                                    # optional; app works offline without it
$env:DAC_PYTHON = "$PWD\.venv\Scripts\python.exe"
npm run dev
```

Backend only (API on http://127.0.0.1:8765, auth off when `DAC_TOKEN` is unset): `python run_backend.py`

## Build the Windows installer

```powershell
npm run dist          # tsc + vite build + PyInstaller backend + electron-builder (NSIS)
```
Output: `release\Device AI Companion Setup 1.0.0.exe`. The installer bundles the backend; users never touch a terminal.
(The installer is unsigned, so SmartScreen will warn. Add a code-signing certificate for distribution.)

## Try the demo

1. Click **Simulate issue → Low disk space**. The floating icon (bottom-right of the desktop) shows a pulsing badge and
   Windows shows a toast. Click either to open the mini-chat.
2. Ask *"Can you clean only old temporary files?"* or tap a **30 days** chip. A **new** plan appears and must be approved again.
3. **Approve cleanup**. Watch progress, then the SIMULATED result; the dashboard's disk card shows a dashed pink
   SIMULATED marker next to the real reading.
4. Repeat with **High memory usage**; try *"Do not close my browser."*
5. **Reset demo** removes all simulated issues and chat; real telemetry is never altered.

## Safety design

| Concern | How it is enforced |
|---|---|
| AI can't act | Phi-4 only returns text + an optional action *name*. `validate_action()` checks it against `ACTIONS` (2 actions) and strictly validates params. There is no "approve" or "run" action. |
| Approval | Execution requires `POST /issues/{id}/approve` with the current `proposal_id`. Any change creates a new proposal id, so old approvals are refused. |
| Disk cleanup | Only `.tmp .temp .log .old .bak .dmp .etl .cache .chk` files inside the temp allowlist (`%TEMP%`, `%WINDIR%\Temp`), never newer than 1 hour, no symlinks/junctions, skips `_MEI*`/Electron dirs. Each file is re-validated (path, extension, size, mtime) right before deletion; files that changed are skipped. Reclaimed space is measured from actual free-space change. |
| Memory | Only user-owned apps with a visible window; protected system/shell/dev tools never listed; identity checked (pid + create time + name) before acting; closed with `WM_CLOSE` (polite, app may prompt to save). **No force-kill code path exists** (a test greps for it). |
| Simulation | Separate `SimulationRemediationExecutor` (arithmetic + sleeps only). Samples enter the same `DetectionEngine` with `simulated=True` (own streak counters). Never written to the telemetry table. Everything is labelled SIMULATED. |
| Network | Binds 127.0.0.1 only; refuses a non-local `DAC_HOST` without `DAC_TOKEN`. Bearer token (random per launch) required on every endpoint except `/api/health`; WebSocket takes `?token=`. |

## API

`GET /api/health` (public) · `GET /api/telemetry` · `GET /api/issues` · `GET /api/issues/{id}` · `GET /api/history` ·
`POST /api/chat` · `POST /api/issues/{id}/approve|reject|propose` · `POST /api/simulate/{disk|memory}` ·
`POST /api/simulate-reset` · `POST /api/refresh` · `GET|PUT /api/config` · `WS /ws`

Send `Authorization: Bearer <DAC_TOKEN>`. WebSocket events: `telemetry`, `issue_alert`, `issue_updated`, `chat_message`,
`remediation_status`, `demo_reset`.

## Configuration

Thresholds live in `settings.json` (in the app data folder), via `PUT /api/config`, or `DAC_*` env vars:
`DISK_FREE_THRESHOLD_PERCENT` (15), `MEMORY_THRESHOLD_PERCENT` (85), `MEMORY_CONSECUTIVE_SAMPLES` (3),
`SAMPLE_INTERVAL_SECONDS` (60), `OLLAMA_MODEL` (phi4), `OLLAMA_URL`.

## Tests

```powershell
npm run test:backend          # 21 core tests; 4 more API tests run once requirements-dev.txt is installed
npm run typecheck
```

## Known limits

- Battery *health* needs WMI battery classes (some laptops/drivers don't expose them) → shows "health not available".
- Windows Focus Assist / Do Not Disturb can hide the toast; the pulsing badge still appears.
- Phi-4 (14B) is slow on CPU-only machines; replies fall back to built-in answers if Ollama doesn't answer in time.
- `%WINDIR%\Temp` needs admin rights to delete from; without them those files are skipped, never forced.
