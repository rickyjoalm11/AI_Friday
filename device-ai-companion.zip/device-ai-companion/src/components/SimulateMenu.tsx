import { useEffect, useRef, useState } from "react";

interface Props { onPick: (kind: "disk" | "memory") => Promise<void>; onReset: () => Promise<void>; simActive: boolean }

export default function SimulateMenu({ onPick, onReset, simActive }: Props) {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const close = (e: MouseEvent) => { if (!ref.current?.contains(e.target as Node)) setOpen(false); };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, []);

  const pick = async (k: "disk" | "memory") => {
    setBusy(true);
    try { await onPick(k); } finally { setBusy(false); setOpen(false); }
  };

  return (
    <div className="relative flex items-center gap-2" ref={ref}>
      {simActive && (
        <button onClick={onReset} className="rounded-lg border border-ink-600 px-3 py-2 text-sm text-fog-dim hover:bg-ink-800">Reset demo</button>
      )}
      <button
        onClick={() => setOpen((o) => !o)} aria-haspopup="menu" aria-expanded={open}
        className="rounded-lg bg-sim px-4 py-2 text-sm font-semibold text-ink-950 hover:brightness-110"
      >
        Simulate issue
      </button>
      {open && (
        <div role="menu" className="absolute right-0 top-12 z-20 w-72 rounded-xl border border-ink-600 bg-ink-800 p-2 shadow-2xl">
          <p className="px-3 pb-2 pt-1 text-xs text-fog-dim">Runs the real detection and approval flow on made-up numbers. Nothing on this PC is changed.</p>
          <button role="menuitem" disabled={busy} onClick={() => pick("disk")} className="block w-full rounded-lg px-3 py-2 text-left text-sm hover:bg-ink-700 disabled:opacity-50">
            Low disk space <span className="text-fog-faint">(95% used)</span>
          </button>
          <button role="menuitem" disabled={busy} onClick={() => pick("memory")} className="block w-full rounded-lg px-3 py-2 text-left text-sm hover:bg-ink-700 disabled:opacity-50">
            High memory usage <span className="text-fog-faint">(92% RAM)</span>
          </button>
        </div>
      )}
    </div>
  );
}
