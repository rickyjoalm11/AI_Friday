import react from "@vitejs/plugin-react";
import { resolve } from "path";
import { defineConfig } from "vite";

// base './' so the built pages load from file:// inside Electron.
export default defineConfig({
  base: "./",
  plugins: [react()],
  server: { port: 5173, strictPort: true },
  build: {
    outDir: "dist",
    rollupOptions: { input: { index: resolve(__dirname, "index.html"), chat: resolve(__dirname, "chat.html") } },
  },
});
