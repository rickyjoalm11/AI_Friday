"""Fixed action registry, strict validation, and the REAL executor.

Safety model
  * The AI can only *name* an action from ACTIONS; validate_action() checks name + params.
  * Nothing runs without a user approval tied to one specific proposal_id (enforced in workflow.py).
  * Disk: only files with allowlisted extensions, inside allowlisted temp folders, older than a floor age,
    re-validated immediately before deletion. No symlinks/junctions are followed.
  * Memory: only user-owned, non-protected apps with a visible window, identity-checked (pid + create_time +
    name), closed with a polite WM_CLOSE (SIGTERM off-Windows). There is no kill()/force-terminate code path.
"""
import math
import os
import re
import stat
import tempfile
import time
from pathlib import Path

import psutil

from .detection import DISK, MEMORY


class ActionError(ValueError):
    """Raised when an action/params fail validation or cannot be executed safely."""


ACTIONS = {
    "cleanup_temp_files": {
        "issue_kind": DISK,
        "label": "Clean up old temporary files",
        "params": {"min_age_days": {"type": "int", "min": 0, "max": 365, "default": 7}},
    },
    "close_application": {
        "issue_kind": MEMORY,
        "label": "Ask one application to close gracefully",
        "params": {"pid": {"type": "int", "min": 1, "required": False},
                   "exclude_apps": {"type": "str_list", "max_items": 10, "required": False}},
    },
}

APP_ALIASES = {
    "browser": ["chrome", "msedge", "edge", "firefox", "brave", "opera", "vivaldi"],
    "browsers": ["chrome", "msedge", "edge", "firefox", "brave", "opera", "vivaldi"],
    "edge": ["msedge"], "google chrome": ["chrome"], "vs code": ["code"], "vscode": ["code"],
    "visual studio code": ["code"], "teams": ["teams", "ms-teams"], "word": ["winword"], "excel": ["excel"],
}


def _norm_app(name: str) -> str:
    n = name.strip().lower()
    return n[:-4] if n.endswith(".exe") else n


def expand_aliases(names) -> list:
    out = []
    for n in names or []:
        n = _norm_app(n)
        if n:
            out.extend(APP_ALIASES.get(n, [n]))
    return out


def validate_action(action, params, issue_kind) -> dict:
    spec = ACTIONS.get(action)
    if spec is None:
        raise ActionError(f"'{action}' is not an allowed action.")
    if spec["issue_kind"] != issue_kind:
        raise ActionError(f"'{action}' does not apply to this kind of issue.")
    params = params if isinstance(params, dict) else {}
    clean = {}
    for name, rule in spec["params"].items():       # unknown keys are dropped, never passed on
        if name not in params or params[name] in (None, ""):
            if "default" in rule:
                clean[name] = rule["default"]
            elif rule.get("required", True):
                raise ActionError(f"Missing parameter '{name}'.")
            continue
        v = params[name]
        if rule["type"] == "int":
            if isinstance(v, bool):
                raise ActionError(f"'{name}' must be a whole number.")
            try:
                v = int(float(v))
            except (TypeError, ValueError):
                raise ActionError(f"'{name}' must be a whole number.")
            if v < rule.get("min", -math.inf) or v > rule.get("max", math.inf):
                raise ActionError(f"'{name}' must be between {rule.get('min')} and {rule.get('max')}.")
        elif rule["type"] == "str_list":
            if isinstance(v, str):
                v = [v]
            if not isinstance(v, list) or len(v) > rule["max_items"]:
                raise ActionError(f"'{name}' must be a short list of names.")
            v = [re.sub(r"[^a-z0-9 ._+-]", "", str(x).lower())[:40].strip() for x in v]
            v = [x for x in v if x]
        clean[name] = v
    return clean


def fmt_bytes(n) -> str:
    n = float(n or 0)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.0f} {unit}" if unit in ("B", "KB") else f"{n:.1f} {unit}"
        n /= 1024


# ============================== DISK ==============================
ALLOWED_EXT = {".tmp", ".temp", ".log", ".old", ".bak", ".dmp", ".etl", ".cache", ".chk"}
SKIP_DIR_PREFIXES = ("_mei", "scoped_dir", "electron", "device ai companion", "device-ai-companion", "dac-")
MIN_AGE_FLOOR_SECONDS = 3600  # never touch anything modified in the last hour, whatever the user asks


def default_allowlist() -> list:
    roots = [Path(tempfile.gettempdir())]
    if os.name == "nt" and os.environ.get("WINDIR"):
        roots.append(Path(os.environ["WINDIR"]) / "Temp")
    return roots


def _within(path, root) -> bool:
    try:
        r = os.path.realpath(root)
        return os.path.commonpath([os.path.realpath(path), r]) == r
    except ValueError:
        return False


def _is_link(path) -> bool:
    return os.path.islink(path) or (hasattr(os.path, "isjunction") and os.path.isjunction(path))


def _file_ok(path, roots, cutoff, expect=None) -> "dict | None":
    """Single eligibility check, used for BOTH the scan and the pre-delete revalidation."""
    try:
        if os.path.splitext(path)[1].lower() not in ALLOWED_EXT or _is_link(path):
            return None
        st = os.lstat(path)
        if not stat.S_ISREG(st.st_mode) or st.st_mtime >= cutoff:
            return None
        if not any(_within(path, r) for r in roots):
            return None
        if expect and (st.st_size != expect["size"] or abs(st.st_mtime - expect["mtime"]) > 1):
            return None
        return {"path": path, "size": st.st_size, "mtime": st.st_mtime}
    except OSError:
        return None


def scan_eligible(roots, min_age_days, now=None) -> list:
    cutoff = (now or time.time()) - max(min_age_days * 86400, MIN_AGE_FLOOR_SECONDS)
    found = []
    for root in roots:
        root = str(root)
        if not os.path.isdir(root) or _is_link(root):
            continue
        for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
            dirnames[:] = [d for d in dirnames
                           if not d.lower().startswith(SKIP_DIR_PREFIXES) and not _is_link(os.path.join(dirpath, d))]
            for fn in filenames:
                f = _file_ok(os.path.join(dirpath, fn), [root], cutoff)
                if f:
                    found.append(f)
    return found


# ============================== MEMORY ==============================
PROTECTED = {
    "system", "system idle process", "registry", "memory compression", "smss.exe", "csrss.exe", "wininit.exe",
    "services.exe", "lsass.exe", "svchost.exe", "winlogon.exe", "explorer.exe", "dwm.exe", "fontdrvhost.exe",
    "sihost.exe", "ctfmon.exe", "taskmgr.exe", "searchhost.exe", "searchindexer.exe", "startmenuexperiencehost.exe",
    "shellexperiencehost.exe", "runtimebroker.exe", "audiodg.exe", "spoolsv.exe", "msmpeng.exe", "securityhealthservice.exe",
    "cmd.exe", "conhost.exe", "powershell.exe", "pwsh.exe", "windowsterminal.exe", "python.exe", "pythonw.exe",
    "ollama.exe", "ollama app.exe", "ollama_llama_server.exe", "electron.exe", "device ai companion.exe",
    "dac-backend.exe", "init", "systemd", "launchd", "kernel_task", "gnome-shell", "Xorg", "xorg",
}
DISPLAY = {"chrome": "Google Chrome", "msedge": "Microsoft Edge", "code": "VS Code", "firefox": "Firefox",
           "teams": "Microsoft Teams", "ms-teams": "Microsoft Teams", "winword": "Microsoft Word", "excel": "Microsoft Excel"}


def _visible_window_pids() -> dict:
    """Windows only: {pid: [hwnd,...]} for visible, titled, un-owned top-level windows."""
    import ctypes
    from ctypes import wintypes
    user32, result = ctypes.windll.user32, {}
    proc_t = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)

    def cb(hwnd, _):
        if user32.IsWindowVisible(hwnd) and user32.GetWindowTextLengthW(hwnd) > 0 and not user32.GetWindow(hwnd, 4):
            pid = wintypes.DWORD()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            result.setdefault(pid.value, []).append(hwnd)
        return True

    user32.EnumWindows(proc_t(cb), 0)
    return result


def _request_close(pids) -> None:
    """Ask politely. Windows: WM_CLOSE to each window (the app may prompt to save). Else: SIGTERM."""
    if os.name == "nt":
        import ctypes
        windows = _visible_window_pids()
        for pid in pids:
            for hwnd in windows.get(pid, []):
                ctypes.windll.user32.PostMessageW(hwnd, 0x0010, 0, 0)  # WM_CLOSE
    else:
        for pid in pids:
            try:
                psutil.Process(pid).terminate()
            except psutil.Error:
                pass


def _alive(pid) -> bool:
    try:
        return psutil.Process(pid).status() != psutil.STATUS_ZOMBIE
    except psutil.Error:
        return False


def _own_pids() -> set:
    pids = {os.getpid()}
    try:
        par = psutil.Process(os.getppid())
        pids.add(par.pid)
        pids.update(c.pid for c in par.children(recursive=True))
        pids.update(a.pid for a in psutil.Process().parents())
    except psutil.Error:
        pass
    return pids


class RealRemediationExecutor:
    simulated = False

    def __init__(self, allowlist=None):
        self.allowlist = [str(p) for p in (allowlist or default_allowlist())]
        self._plans = {}  # proposal_id -> approved snapshot (what was previewed)

    def _remember(self, pid, plan):
        self._plans[pid] = plan
        for old in list(self._plans)[:-8]:
            del self._plans[old]

    # ---------- candidates / preview ----------
    def list_candidates(self, exclude_apps=(), limit=5) -> list:
        tokens = expand_aliases(exclude_apps)
        windows = _visible_window_pids() if os.name == "nt" else None
        own, win = _own_pids(), os.environ.get("WINDIR", "").lower()
        try:
            me = psutil.Process().username()
        except psutil.Error:
            me = None
        total = psutil.virtual_memory().total
        groups = {}
        for p in psutil.process_iter(["pid", "name", "username", "memory_info", "create_time", "exe"]):
            try:
                i = p.info
                name = (i["name"] or "").lower()
                if not name or name in PROTECTED or i["pid"] in own or not me or i["username"] != me:
                    continue
                if win and (i["exe"] or "").lower().startswith(win):
                    continue
                groups.setdefault(name, []).append((i["pid"], i["create_time"], i["memory_info"].rss))
            except (psutil.Error, AttributeError, TypeError):
                continue
        out = []
        for name, procs in groups.items():
            has_window = windows is None or any(pid in windows for pid, _, _ in procs)
            base = _norm_app(name)
            if not has_window or any(t in base for t in tokens):
                continue
            procs.sort(key=lambda t: (windows is not None and t[0] not in windows, t[1]))
            rss = sum(t[2] for t in procs)
            out.append({"name": name, "display_name": DISPLAY.get(base, base[:1].upper() + base[1:]),
                        "pid": procs[0][0], "create_time": procs[0][1],
                        "procs": [[pid, ct] for pid, ct, _ in procs],
                        "memory_mb": round(rss / 2**20), "memory_percent": round(100 * rss / total, 1)})
        out.sort(key=lambda c: c["memory_mb"], reverse=True)
        return out[:limit]

    def preview(self, proposal_id, action, params, exclude_apps=()) -> dict:
        if action == "cleanup_temp_files":
            days = params["min_age_days"]
            files = scan_eligible(self.allowlist, days)
            total = sum(f["size"] for f in files)
            self._remember(proposal_id, {"files": files, "min_age_days": days})
            top = sorted(files, key=lambda f: f["size"], reverse=True)[:6]
            if not files:
                raise ActionError(f"No eligible temporary files older than {days} days were found.")
            return {
                "kind": "disk", "simulated": False, "file_count": len(files), "total_bytes": total,
                "min_age_days": days, "folders": self.allowlist,
                "examples": [{"path": f["path"], "size": f["size"]} for f in top],
                "summary": f"Delete {len(files):,} temporary files older than {days} day(s), about {fmt_bytes(total)}, "
                           f"from: {', '.join(self.allowlist)}.",
                "risk": "Only .tmp/.log/.bak-style files in the folders above. Documents and system files are never touched.",
            }
        if action == "close_application":
            cands = self.list_candidates(exclude_apps)
            if not cands:
                raise ActionError("No eligible applications to close (protected and excluded apps are never listed).")
            pid = params.get("pid")
            sel = next((c for c in cands if c["pid"] == pid), None) if pid else cands[0]
            if sel is None:
                raise ActionError("That process is not an eligible, closable application.")
            self._remember(proposal_id, {"selected": sel})
            return {
                "kind": "memory", "simulated": False, "candidates": cands, "selected": sel,
                "summary": f"Ask {sel['display_name']} to close (frees about {sel['memory_mb']:,} MB, "
                           f"{sel['memory_percent']}% of RAM).",
                "risk": "Unsaved work in that app could be lost. It will be asked to close normally and may show a save prompt. "
                        "It is never force-closed.",
            }
        raise ActionError("Unsupported action.")

    # ---------- execute ----------
    def execute(self, proposal_id, action, params, progress) -> dict:
        plan = self._plans.get(proposal_id)
        if plan is None:
            raise ActionError("This preview has expired. Ask me for a fresh proposal.")
        return self._exec_disk(plan, progress) if action == "cleanup_temp_files" else self._exec_memory(plan, progress)

    def _exec_disk(self, plan, progress) -> dict:
        drive = os.path.splitdrive(self.allowlist[0])[0] + "\\" if os.name == "nt" else "/"
        before = psutil.disk_usage(drive)
        cutoff = time.time() - max(plan["min_age_days"] * 86400, MIN_AGE_FLOOR_SECONDS)
        progress(10, "Re-checking every approved file…")
        todo = [f for f in plan["files"] if _file_ok(f["path"], self.allowlist, cutoff, expect=f)]
        skipped_changed = len(plan["files"]) - len(todo)
        deleted = freed = failed = 0
        for n, f in enumerate(todo, 1):
            try:
                os.remove(f["path"])
                deleted += 1
                freed += f["size"]
            except OSError:
                failed += 1  # in use / permission denied: leave it alone
            if n % 25 == 0 or n == len(todo):
                progress(10 + int(85 * n / max(len(todo), 1)), f"Deleted {deleted:,} files…")
        after = psutil.disk_usage(drive)
        measured = max(0, after.free - before.free)
        return {
            "simulated": False, "executed": deleted > 0,
            "summary": f"Deleted {deleted:,} files. Free space changed by {fmt_bytes(measured)} "
                       f"({fmt_bytes(freed)} of file data removed). Disk is now {after.percent:.0f}% used."
                       + (f" Skipped {skipped_changed + failed} files that changed or were in use." if skipped_changed + failed else ""),
            "details": {"files_deleted": deleted, "bytes_deleted": freed, "reclaimed_bytes_measured": measured,
                        "skipped": skipped_changed + failed},
            "metrics_after": {"disk_percent": round(after.percent, 1), "disk_free_percent": round(100 - after.percent, 1)},
        }

    def _exec_memory(self, plan, progress) -> dict:
        sel = plan["selected"]
        before = psutil.virtual_memory().percent
        progress(10, f"Verifying {sel['display_name']} is the same process you approved…")
        live = []
        for pid, ct in sel["procs"]:
            try:
                p = psutil.Process(pid)
                if abs(p.create_time() - ct) <= 1 and p.name().lower() == sel["name"]:
                    live.append(pid)
            except psutil.Error:
                pass
        if sel["pid"] not in live:
            raise ActionError(f"{sel['display_name']} is no longer the process you approved, so nothing was closed.")
        progress(30, f"Asking {sel['display_name']} to close…")
        _request_close(live)
        deadline = time.time() + 20
        while time.time() < deadline:
            if not any(_alive(p) for p in live):
                break
            time.sleep(0.5)
            progress(30 + int(50 * (1 - (deadline - time.time()) / 20)), "Waiting for the app to finish closing…")
        closed = not any(_alive(p) for p in live)
        if closed:
            time.sleep(2)
        progress(95, "Re-checking memory…")
        after = psutil.virtual_memory().percent
        msg = (f"{sel['display_name']} closed. RAM went from {before:.0f}% to {after:.0f}%." if closed else
               f"{sel['display_name']} is still running — it may be asking you to save work. I did not force it to close.")
        return {"simulated": False, "executed": closed, "summary": msg,
                "details": {"app": sel["display_name"], "ram_before": before, "ram_after": after},
                "metrics_after": {"ram_percent": round(after, 1)}}
