"""Settings: defaults < settings.json in the data dir < DAC_* environment variables."""
import json
import os
from dataclasses import asdict, dataclass, fields
from pathlib import Path


def data_dir() -> Path:
    p = Path(os.environ.get("DAC_DATA_DIR") or (Path.home() / ".device-ai-companion"))
    p.mkdir(parents=True, exist_ok=True)
    return p


@dataclass
class Settings:
    disk_free_threshold_percent: float = 15.0   # Rule 1: trigger when free space < this
    memory_threshold_percent: float = 85.0      # Rule 2: trigger when RAM > this ...
    memory_consecutive_samples: int = 3         # ... for this many consecutive samples
    sample_interval_seconds: int = 60
    reject_cooldown_minutes: int = 30           # don't re-alert a rejected real issue for this long
    history_limit: int = 500
    ollama_url: str = "http://127.0.0.1:11434"
    ollama_model: str = "phi4"
    ollama_timeout_seconds: int = 90
    ai_summaries: bool = True

    @classmethod
    def load(cls, path: Path | None = None) -> "Settings":
        s = cls()
        path = path or (data_dir() / "settings.json")
        if path.exists():
            try:
                s.apply(json.loads(path.read_text("utf-8")), persist=False)
            except (OSError, ValueError):
                pass
        for f in fields(cls):
            env = os.environ.get("DAC_" + f.name.upper())
            if env is not None:
                try:
                    s.apply({f.name: env}, persist=False)
                except ValueError:
                    pass
        s._path = path  # type: ignore[attr-defined]
        return s

    def apply(self, values: dict, persist: bool = True) -> None:
        known = {f.name for f in fields(self)}
        clean = {}
        for k, v in values.items():
            if k not in known:
                raise ValueError(f"Unknown setting: {k}")
            cur = getattr(self, k)
            if isinstance(cur, bool):
                v = v if isinstance(v, bool) else str(v).lower() in ("1", "true", "yes")
            elif isinstance(cur, int):
                v = int(v)
            elif isinstance(cur, float):
                v = float(v)
            else:
                v = str(v)
            clean[k] = v
        d = clean.get("disk_free_threshold_percent", self.disk_free_threshold_percent)
        m = clean.get("memory_threshold_percent", self.memory_threshold_percent)
        if not 0 < d < 100:
            raise ValueError("disk_free_threshold_percent must be between 0 and 100")
        if not 1 <= m <= 100:
            raise ValueError("memory_threshold_percent must be between 1 and 100")
        if clean.get("memory_consecutive_samples", self.memory_consecutive_samples) < 1:
            raise ValueError("memory_consecutive_samples must be >= 1")
        if clean.get("sample_interval_seconds", self.sample_interval_seconds) < 5:
            raise ValueError("sample_interval_seconds must be >= 5")
        for k, v in clean.items():
            setattr(self, k, v)
        if persist and getattr(self, "_path", None):
            self._path.write_text(json.dumps(asdict(self), indent=2), "utf-8")

    def as_dict(self) -> dict:
        return asdict(self)
