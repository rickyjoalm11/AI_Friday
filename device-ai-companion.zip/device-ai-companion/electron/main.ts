import { app, BrowserWindow, dialog, ipcMain, Menu, Notification, screen } from "electron";
import path from "path";
import WebSocket from "ws";
import { BackendInfo, BackendProcess } from "./backend";

const DEV = process.env.VITE_DEV === "1";
const BUBBLE = { w: 76, h: 76 };
const CHAT = { w: 392, h: 600 };

const backend = new BackendProcess();
let info: BackendInfo | null = null;
let startError: string | null = null;
let dashboard: BrowserWindow | null = null;
let bubble: BrowserWindow | null = null;
let bubbleOpen = false;
let collapsedBounds: Electron.Rectangle | null = null;
let quitting = false;

const page = (name: string) =>
  DEV ? `http://localhost:5173/${name}.html` : `file://${path.join(__dirname, "..", "dist", `${name}.html`)}`;

function webPrefs(): Electron.WebPreferences {
  return { preload: path.join(__dirname, "preload.js"), contextIsolation: true, nodeIntegration: false, sandbox: true };
}

function createDashboard() {
  dashboard = new BrowserWindow({
    width: 1040, height: 740, minWidth: 820, minHeight: 600, backgroundColor: "#0b1017",
    title: "Device AI Companion", autoHideMenuBar: true, webPreferences: webPrefs(),
  });
  dashboard.loadURL(page("index"));
  // Closing the dashboard keeps the floating companion alive; quit from the bubble menu or the dashboard header.
  dashboard.on("close", (e) => { if (!quitting) { e.preventDefault(); dashboard?.hide(); } });
}

function showDashboard() {
  if (!dashboard || dashboard.isDestroyed()) createDashboard();
  dashboard!.show();
  dashboard!.focus();
}

function createBubble() {
  const wa = screen.getPrimaryDisplay().workArea;
  bubble = new BrowserWindow({
    width: BUBBLE.w, height: BUBBLE.h, x: wa.x + wa.width - BUBBLE.w - 28, y: wa.y + wa.height - BUBBLE.h - 28,
    frame: false, transparent: true, resizable: false, skipTaskbar: true, alwaysOnTop: true, hasShadow: false,
    focusable: true, webPreferences: webPrefs(),
  });
  bubble.setAlwaysOnTop(true, "screen-saver");
  bubble.loadURL(page("chat"));
}

function setBubbleOpen(open: boolean) {
  if (!bubble || bubble.isDestroyed() || open === bubbleOpen) return;
  bubbleOpen = open;
  if (open) {
    collapsedBounds = bubble.getBounds();
    const wa = screen.getDisplayMatching(collapsedBounds).workArea;
    const cx = collapsedBounds.x + collapsedBounds.width / 2 - wa.x;
    const cy = collapsedBounds.y + collapsedBounds.height / 2 - wa.y;
    // Grow toward the centre of the screen so the panel never leaves the work area.
    let x = cx > wa.width / 2 ? collapsedBounds.x + collapsedBounds.width - CHAT.w : collapsedBounds.x;
    let y = cy > wa.height / 2 ? collapsedBounds.y + collapsedBounds.height - CHAT.h : collapsedBounds.y;
    x = Math.min(Math.max(x, wa.x), wa.x + wa.width - CHAT.w);
    y = Math.min(Math.max(y, wa.y), wa.y + wa.height - CHAT.h);
    bubble.setBounds({ x, y, width: CHAT.w, height: CHAT.h });
    bubble.focus();
  } else if (collapsedBounds) {
    bubble.setBounds(collapsedBounds);
  }
}

function openChat(issueId: string | null) {
  if (!bubble || bubble.isDestroyed()) createBubble();
  bubble!.show();
  setBubbleOpen(true);
  bubble!.webContents.send("chat:open-issue", issueId);
}

// --- main-process WebSocket client: desktop notifications even if the UI windows are idle ---------------
let ws: WebSocket | null = null;
function connectEvents() {
  if (!info || quitting) return;
  ws = new WebSocket(info.wsUrl);
  ws.on("message", (raw) => {
    try {
      const m = JSON.parse(raw.toString());
      if (m.type === "issue_alert") notifyIssue(m.issue);
    } catch { /* ignore malformed */ }
  });
  ws.on("close", () => { if (!quitting) setTimeout(connectEvents, 2000); });
  ws.on("error", () => ws?.close());
}

function notifyIssue(issue: { id: string; title: string; simulated: boolean; kind: string }) {
  const sim = issue.simulated ? "[SIMULATED] " : "";
  const body = issue.kind === "low_disk"
    ? "Free disk space is low. I have a cleanup plan ready for your approval."
    : "Memory has been high for a while. I have a suggestion ready for your approval.";
  if (Notification.isSupported()) {
    const n = new Notification({ title: `${sim}${issue.title}`, body });
    n.on("click", () => openChat(issue.id));
    n.show();
  }
  // Pop the floating icon to the front; its renderer shows the badge.
  bubble?.showInactive();
}

// --- IPC -------------------------------------------------------------------------------------------------
ipcMain.handle("dac:get-config", async () => {
  for (let i = 0; i < 400 && !info && !startError; i++) await new Promise((r) => setTimeout(r, 100));
  return info ? { baseUrl: info.baseUrl, wsUrl: info.wsUrl, token: info.token } : { error: startError ?? "Backend not started" };
});
ipcMain.on("dac:open-chat", (_e, id: string | null) => openChat(id));
ipcMain.on("bubble:set-open", (_e, open: boolean) => setBubbleOpen(open));
ipcMain.on("bubble:drag-by", (_e, dx: number, dy: number) => {
  if (!bubble || bubbleOpen) return;
  const b = bubble.getBounds();
  bubble.setPosition(Math.round(b.x + dx), Math.round(b.y + dy));
});
ipcMain.on("dac:show-dashboard", showDashboard);
ipcMain.on("dac:quit", () => app.quit());
ipcMain.on("bubble:context-menu", () => {
  Menu.buildFromTemplate([
    { label: "Open dashboard", click: showDashboard },
    { type: "separator" },
    { label: "Quit Device AI Companion", click: () => app.quit() },
  ]).popup({ window: bubble ?? undefined });
});

// --- lifecycle -------------------------------------------------------------------------------------------
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on("second-instance", showDashboard);
  app.setAppUserModelId("com.deviceai.companion"); // required for Windows toast notifications

  app.whenReady().then(async () => {
    createDashboard();
    createBubble();
    try {
      info = await backend.start();
      connectEvents();
    } catch (e) {
      startError = (e as Error).message;
      dialog.showErrorBox("Device AI Companion couldn't start its monitoring service", startError);
    }
  });

  app.on("before-quit", (e) => {
    if (quitting) return;
    quitting = true;
    e.preventDefault();
    ws?.close();
    backend.stop().finally(() => app.exit(0));
  });
  app.on("window-all-closed", () => { /* keep running: the floating companion is the main surface */ });
}
