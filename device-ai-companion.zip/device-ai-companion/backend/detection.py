"""Issue detection engine. Real and simulated samples go through the SAME rules,
but streak counters and de-duplication are tracked separately so synthetic data never mixes with real."""
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

DISK, MEMORY = "low_disk", "high_memory"


@dataclass
class Detection:
    kind: str
    title: str
    simulated: bool
    metric: dict
    severity: str = "warning"


class DetectionEngine:
    def __init__(self, settings, db):
        self.settings = settings
        self.db = db
        self._streak = {False: 0, True: 0}

    def reset_streak(self, simulated=None):
        for k in ([simulated] if simulated is not None else [False, True]):
            self._streak[k] = 0

    def is_cleared(self, kind: str, sample: dict) -> bool:
        s = self.settings
        if kind == DISK:
            return sample["disk_free_percent"] >= s.disk_free_threshold_percent
        if kind == MEMORY:
            return sample["ram_percent"] <= s.memory_threshold_percent
        return True

    def _suppressed(self, kind, simulated) -> bool:
        if self.db.active_issue(kind, simulated):
            return True  # one active issue per rule: never notify twice
        if not simulated:
            rej = self.db.last_rejected(kind, simulated)
            if rej:
                age = datetime.now(timezone.utc) - datetime.fromisoformat(rej["updated_at"])
                if age < timedelta(minutes=self.settings.reject_cooldown_minutes):
                    return True
        return False

    def evaluate(self, sample: dict, simulated: bool = False) -> list:
        s, found = self.settings, []
        # Rule 1: low disk space (free < threshold)
        if sample["disk_free_percent"] < s.disk_free_threshold_percent and not self._suppressed(DISK, simulated):
            found.append(Detection(
                DISK, "Low disk space", simulated,
                {"disk_percent": sample["disk_percent"], "free_percent": sample["disk_free_percent"],
                 "free_bytes": sample["disk_free_bytes"], "total_bytes": sample["disk_total_bytes"],
                 "drive": sample["disk_path"], "threshold_free_percent": s.disk_free_threshold_percent},
                "critical" if sample["disk_free_percent"] < 5 else "warning"))
        # Rule 2: RAM above threshold for N consecutive samples
        if sample["ram_percent"] > s.memory_threshold_percent:
            self._streak[simulated] += 1
        else:
            self._streak[simulated] = 0
        if self._streak[simulated] >= s.memory_consecutive_samples and not self._suppressed(MEMORY, simulated):
            found.append(Detection(
                MEMORY, "High memory usage", simulated,
                {"ram_percent": sample["ram_percent"], "samples": self._streak[simulated],
                 "threshold_percent": s.memory_threshold_percent,
                 "used_bytes": sample.get("ram_used_bytes"), "total_bytes": sample.get("ram_total_bytes")},
                "critical" if sample["ram_percent"] > 95 else "warning"))
        return found
