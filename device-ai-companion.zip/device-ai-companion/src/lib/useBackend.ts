import { useEffect, useState } from "react";
import { Api, connect } from "./api";

export function useBackend() {
  const [api, setApi] = useState<Api | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    connect().then(setApi).catch((e: Error) => setError(e.message));
  }, []);
  return { api, error };
}
