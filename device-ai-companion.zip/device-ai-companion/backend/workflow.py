"""Issue state machine + approval workflow + chat. The ONLY place that executes remediation.
Real and simulated issues take exactly the same path; only the executor differs."""
import asyncio
import uuid

from .ai_service import fallback_explain
from .database import now
from .detection import DISK, MEMORY, Detection
from .remediation import ACTIONS, ActionError, validate_action


class WorkflowError(Exception):
    pass


TRANSITIONS = {
    "detected": {"awaiting_approval", "rejected", "resolved"},
    "awaiting_approval": {"awaiting_approval", "executing", "rejected", "resolved"},
    "executing": {"resolved", "failed"},
    "failed": {"awaiting_approval", "rejected", "resolved"},
    "rejected": {"awaiting_approval"},
    "resolved": set(),
}
MODIFIABLE = {"detected", "awaiting_approval", "failed", "rejected"}
DEFAULT_ACTION = {DISK: ("cleanup_temp_files", {"min_age_days": 7}), MEMORY: ("close_application", {})}


class IssueWorkflow:
    def __init__(self, db, ws, ai, engine, sim, real_exec, sim_exec, get_real_sample):
        self.db, self.ws, self.ai, self.engine, self.sim = db, ws, ai, engine, sim
        self.real_exec, self.sim_exec, self.get_real_sample = real_exec, sim_exec, get_real_sample
        self.tasks = {}
        self.on_real_change = None  # optional async callback to refresh telemetry after a real remediation

    # ------------------------------------------------------------ helpers
    def _exec(self, issue):
        return self.sim_exec if issue["simulated"] else self.real_exec

    def _transition(self, issue, new, **fields):
        if new not in TRANSITIONS[issue["status"]]:
            raise WorkflowError(f"Can't move from '{issue['status']}' to '{new}'.")
        updated = self.db.update_issue(issue["id"], status=new, **fields)
        self.db.add_event(issue["id"], f"{issue['status']}->{new}", "", issue["simulated"])
        return updated

    async def _push(self, issue, typ="issue_updated"):
        await self.ws.broadcast({"type": typ, "issue": issue})

    async def _say(self, issue_id, role, text, simulated=False):
        msg = self.db.add_message(issue_id, role, text, simulated)
        await self.ws.broadcast({"type": "chat_message", "message": msg})
        return msg

    def _sample_for(self, issue):
        real = self.get_real_sample()
        if issue and issue["simulated"]:
            s = dict(real) if real else self.sim._base(None)
            o = self.sim.overlay or {}
            if o.get("disk_percent") is not None:
                s.update(disk_percent=o["disk_percent"], disk_free_percent=o["disk_free_percent"])
            if o.get("ram_percent") is not None:
                s["ram_percent"] = o["ram_percent"]
            s["simulated"] = True
            return s
        return real or self.sim._base(None) | {"simulated": False}

    def _context(self, issue, message=""):
        sample = self._sample_for(issue)
        excl = (issue or {}).get("context", {}).get("exclude_apps", []) if issue else []
        cands = self._exec(issue).list_candidates(excl) if issue and issue["kind"] == MEMORY else []
        result = (issue or {}).get("result")
        llm = {
            "issue": issue and {k: issue[k] for k in ("kind", "title", "status", "simulated", "metric")},
            "telemetry": {k: sample.get(k) for k in ("cpu_percent", "ram_percent", "disk_percent", "disk_free_percent", "simulated")}
                         | {"battery_percent": sample["battery"].get("percent")},
            "current_proposal": issue and issue.get("proposal") and {
                "action": issue["proposal"]["action"], "params": issue["proposal"]["params"],
                "summary": issue["proposal"]["preview"]["summary"], "risk": issue["proposal"]["preview"]["risk"]},
            "closable_apps": [{"name": c["display_name"], "memory_mb": c["memory_mb"], "pid": c["pid"]} for c in cands],
            "excluded_apps": excl,
            "last_result": result and result["summary"],
            "allowed_actions": {k: {"label": v["label"], "params": v["params"]} for k, v in ACTIONS.items()
                                if not issue or v["issue_kind"] == issue["kind"]},
        }
        hist = self.db.messages(issue["id"] if issue else None, 10)
        return {"issue": issue, "sample": sample, "candidates": cands, "result": result, "history": hist, "llm_context": llm}

    # ------------------------------------------------------------ detection -> issue
    async def on_detection(self, det: Detection):
        issue = self.db.create_issue(det.kind, det.title, det.simulated, det.metric, det.severity, {"exclude_apps": []})
        self.db.add_event(issue["id"], "detected", det.title, det.simulated)
        tag = "SIMULATED " if det.simulated else ""
        try:
            issue = await self._make_proposal(issue, *DEFAULT_ACTION[det.kind])
            explanation = fallback_explain(self._context(issue))
        except (ActionError, WorkflowError) as e:
            explanation = f"{tag}{det.title}. I couldn't find a safe fix automatically: {e}"
        issue = self.db.update_issue(issue["id"], explanation=explanation)
        await self._say(issue["id"], "assistant", explanation, det.simulated)
        await self._push(issue, "issue_alert")
        asyncio.create_task(self._ai_explain(issue["id"]))
        return issue

    async def _ai_explain(self, issue_id):
        try:
            issue = self.db.get_issue(issue_id)
            if not issue or issue["status"] not in ("awaiting_approval", "detected"):
                return
            text = await self.ai.explain(self._context(issue))
            if text and text != issue["explanation"] and self.ai.last_status["mode"] == "ollama":
                issue = self.db.update_issue(issue_id, explanation=text)
                await self._say(issue_id, "assistant", text, issue["simulated"])
                await self._push(issue)
        except Exception:
            pass

    # ------------------------------------------------------------ proposals
    async def _make_proposal(self, issue, action, params):
        ctx = dict(issue.get("context") or {})
        clean = validate_action(action, params, issue["kind"])
        excl = sorted(set(ctx.get("exclude_apps", [])) | set(clean.pop("exclude_apps", [])))
        ctx["exclude_apps"] = excl
        pid = uuid.uuid4().hex[:10]
        preview = await asyncio.to_thread(self._exec(issue).preview, pid, action, clean, excl)
        proposal = {"proposal_id": pid, "action": action, "params": clean, "preview": preview,
                    "simulated": issue["simulated"], "created_at": now()}
        updated = self._transition(issue, "awaiting_approval", proposal=proposal, context=ctx)
        self.db.add_event(issue["id"], "proposal", f"{action} {clean}", issue["simulated"])
        return updated

    async def propose(self, issue_id, action, params):
        issue = self._get(issue_id)
        if issue["status"] not in MODIFIABLE:
            raise WorkflowError(f"This issue is {issue['status']}; its plan can't be changed.")
        try:
            issue = await self._make_proposal(issue, action, params)
        except ActionError as e:
            raise WorkflowError(str(e))
        await self._push(issue)
        return issue

    def _get(self, issue_id):
        issue = self.db.get_issue(issue_id)
        if not issue:
            raise WorkflowError("Issue not found.")
        return issue

    # ------------------------------------------------------------ approve / reject
    async def approve(self, issue_id, proposal_id):
        issue = self._get(issue_id)
        prop = issue.get("proposal")
        if issue["status"] != "awaiting_approval":
            raise WorkflowError(f"Nothing to approve: issue is {issue['status']}.")
        if not prop or prop["proposal_id"] != proposal_id:
            raise WorkflowError("This plan was changed after you opened it. Review the new plan and approve again.")
        prop = {**prop, "approved_at": now()}
        issue = self._transition(issue, "executing", proposal=prop)
        self.db.add_event(issue_id, "approved", prop["proposal_id"], issue["simulated"])
        await self._push(issue)
        self.tasks[issue_id] = asyncio.create_task(self._run(issue_id))
        return issue

    async def join(self, issue_id):
        t = self.tasks.get(issue_id)
        if t:
            await t

    async def _run(self, issue_id):
        issue = self.db.get_issue(issue_id)
        prop, loop = issue["proposal"], asyncio.get_running_loop()

        def progress(pct, msg):
            asyncio.run_coroutine_threadsafe(self.ws.broadcast(
                {"type": "remediation_status", "issue_id": issue_id, "status": "executing", "progress": pct,
                 "message": msg, "simulated": issue["simulated"]}), loop)

        try:
            result = await asyncio.to_thread(self._exec(issue).execute, prop["proposal_id"], prop["action"], prop["params"], progress)
        except Exception as e:  # ActionError or unexpected: never leave the issue stuck in "executing"
            result = {"simulated": issue["simulated"], "executed": False, "summary": f"Nothing was changed: {e}",
                      "details": {}, "metrics_after": None}
        after = result.get("metrics_after")
        cleared = bool(result["executed"] and after and self.engine.is_cleared(issue["kind"], {
            "disk_free_percent": after.get("disk_free_percent", 100), "ram_percent": after.get("ram_percent", 0)}))
        result["success"] = cleared
        if result["executed"] and not cleared:
            result["summary"] += " The metric is still past its threshold, so the issue stays open — I can propose another step."
        status = "resolved" if cleared else "failed"
        issue = self.db.get_issue(issue_id)
        issue = self._transition(issue, status, result=result)
        self.db.add_event(issue_id, "result", result["summary"], issue["simulated"])
        if issue["simulated"]:
            if after:
                self.sim.apply_result(after, cleared)
        else:
            self.engine.reset_streak(False)
        await self._say(issue_id, "assistant", result["summary"], issue["simulated"])
        await self._push(issue)
        await self.ws.broadcast({"type": "remediation_status", "issue_id": issue_id, "status": status, "progress": 100,
                                 "message": result["summary"], "simulated": issue["simulated"]})
        if not issue["simulated"] and self.on_real_change:
            asyncio.create_task(self.on_real_change())

    async def reject(self, issue_id):
        issue = self._get(issue_id)
        issue = self._transition(issue, "rejected")
        await self._say(issue_id, "assistant", "Okay, I won't do anything. "
                        + ("I'll stay quiet about this for a while." if not issue["simulated"] else "Simulated issue dismissed."),
                        issue["simulated"])
        await self._push(issue)
        return issue

    async def auto_resolve(self, sample):
        """Real issues whose condition cleared on their own (user freed space, closed an app...)."""
        for issue in self.db.list_issues(active_only=True):
            if issue["simulated"] or issue["status"] not in ("detected", "awaiting_approval", "failed"):
                continue
            if self.engine.is_cleared(issue["kind"], sample):
                issue = self._transition(issue, "resolved", result={
                    "simulated": False, "executed": False, "success": True,
                    "summary": "The metric is back within its normal range, so no action was needed.", "details": {}})
                await self._say(issue["id"], "assistant", issue["result"]["summary"])
                await self._push(issue)

    # ------------------------------------------------------------ chat
    async def chat(self, message, issue_id=None):
        issue = self._get(issue_id) if issue_id else None
        sim = bool(issue and issue["simulated"])
        await self._say(issue_id, "user", message, sim)
        if issue and issue["status"] == "executing":
            reply = "The approved action is running now. I'll post the result as soon as it finishes."
            await self._say(issue_id, "assistant", reply, sim)
            return {"reply": reply, "issue": issue}
        ctx = self._context(issue, message)
        out = await self.ai.interpret(message, ctx)
        reply = out["reply"]
        if issue and out["action"] != "none":
            if issue["status"] not in MODIFIABLE:
                reply += f"\n\n(This issue is {issue['status']}, so I can't change its plan.)"
            else:
                try:
                    cur = issue.get("proposal") or {}
                    old_excl = set((issue.get("context") or {}).get("exclude_apps", []))
                    clean = validate_action(out["action"], out["params"], issue["kind"])
                    new_excl = old_excl | set(clean.get("exclude_apps", []))
                    same = (cur.get("action") == out["action"] and issue["status"] == "awaiting_approval"
                            and {k: v for k, v in clean.items() if k != "exclude_apps"} == cur.get("params")
                            and new_excl == old_excl)
                    if not same:
                        issue = await self.propose(issue_id, out["action"], out["params"])
                        p = issue["proposal"]["preview"]
                        reply += f"\n\nUpdated plan: {p['summary']}\nThis is a new proposal, so it needs your approval — nothing has run."
                except (ActionError, WorkflowError) as e:
                    reply += f"\n\nI couldn't turn that into a safe action: {e}"
        await self._say(issue_id, "assistant", reply, sim)
        return {"reply": reply, "issue": issue and self.db.get_issue(issue_id)}

    # ------------------------------------------------------------ simulation + reset
    async def simulate(self, kind):
        """kind: 'disk' | 'memory'. Samples go through the real DetectionEngine as simulated=True."""
        if kind not in ("disk", "memory"):
            raise WorkflowError("Unknown simulation.")
        rule = DISK if kind == "disk" else MEMORY
        if self.db.active_issue(rule, True):
            raise WorkflowError("A simulated issue of this type is already active. Use Reset demo first.")
        real = self.get_real_sample()
        samples = self.sim.disk_samples(real) if kind == "disk" else self.sim.memory_samples(real)
        self.engine.reset_streak(True)
        dets = []
        for s in samples:
            dets += self.engine.evaluate(s, simulated=True)
        if not dets:
            raise WorkflowError("The detection engine did not raise an issue (check thresholds in settings).")
        return await self.on_detection(dets[0])

    async def reset_demo(self):
        for iid, t in list(self.tasks.items()):
            i = self.db.get_issue(iid)
            if i and i["simulated"] and not t.done():
                t.cancel()
        self.db.delete_simulated()
        self.sim.reset()
        self.engine.reset_streak(True)
        await self.ws.broadcast({"type": "demo_reset"})
