# Packages the Python backend into backend/dist/dac-backend/dac-backend.exe (PyInstaller, one-folder).
$ErrorActionPreference = "Stop"
$py = if (Test-Path ".\.venv\Scripts\python.exe") { ".\.venv\Scripts\python.exe" } else { "python" }
& $py -m pip install -r requirements-dev.txt
& $py -m PyInstaller run_backend.py --noconfirm --clean --onedir --name dac-backend `
  --distpath backend/dist --workpath build/pyi --specpath build/pyi --paths . `
  --hidden-import backend.main `
  --collect-submodules uvicorn --collect-submodules websockets --collect-submodules anyio `
  --collect-submodules fastapi --collect-submodules starlette --collect-submodules pydantic
if (-not (Test-Path "backend/dist/dac-backend/dac-backend.exe")) { throw "PyInstaller did not produce dac-backend.exe" }
Write-Host "Backend packaged: backend/dist/dac-backend/dac-backend.exe"
