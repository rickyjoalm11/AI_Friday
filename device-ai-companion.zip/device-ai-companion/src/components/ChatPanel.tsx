import { FormEvent, useEffect, useRef, useState } from "react";
import type { AiStatus, Issue, Message } from "../lib/types";
import ProposalCard from "./ProposalCard";

interface Props {
  issue: Issue | null;
  messages: Message[];
  progress: { pct: number; message: string } | null;
  ai: AiStatus | null;
  busy: boolean;
  error: string | null;
  onSend: (text: string) => void;
  onApprove: () => void;
  onReject: () => void;
  onPropose: (action: string, params: Record<string, unknown>) => void;
  onMinimize: () => void;
}

const STATUS: Record<string, string> = {
  detected: "Detected", awaiting_approval: "Waiting for you", executing: "Running", resolved: "Resolved", failed: "Needs another step", rejected: "Dismissed",
};

function chips(issue: Issue | null): string[] {
  if (!issue) return ["How is my device?", "What do you recommend?"];
  if (issue.status === "resolved" || issue.status === "failed") return ["Was the remediation successful?", "How is my device?"];
  return issue.kind === "low_disk"
    ? ["What is consuming disk space?", "Can you clean only old temporary files?", "What do you recommend?"]
    : ["Why is my RAM high?", "Do not close my browser.", "What do you recommend?"];
}

export default function ChatPanel(p: Props) {
  const [text, setText] = useState("");
  const endRef = useRef<HTMLDivElement>(null);
  useEffect(() => { endRef.current?.scrollIntoView({ block: "end" }); }, [p.messages.length, p.progress?.pct, p.issue?.status]);
  const submit = (e: FormEvent) => { e.preventDefault(); if (text.trim() && !p.busy) { p.onSend(text.trim()); setText(""); } };
  const issue = p.issue;
  const m = issue?.metric ?? {};

  return (
    <div className="flex h-full flex-col overflow-hidden rounded-2xl border border-ink-600 bg-ink-900 shadow-2xl">
      <header className="drag flex items-center justify-between border-b border-ink-700 px-4 py-3">
        <div>
          <h1 className="text-sm font-semibold">Device AI Companion</h1>
          <p className="flex items-center gap-1.5 text-[11px] text-fog-dim">
            <span className={`h-1.5 w-1.5 rounded-full ${p.ai?.available ? "bg-good" : "bg-warn"}`} />
            {p.ai?.available ? `${p.ai.model} · local` : "Offline mode"}
          </p>
        </div>
        <button onClick={p.onMinimize} aria-label="Minimize chat" className="no-drag rounded-md px-2 py-1 text-lg leading-none text-fog-dim hover:bg-ink-700">–</button>
      </header>

      {issue && (
        <div className={`mx-3 mt-3 rounded-xl border px-3 py-2.5 ${issue.simulated ? "border-sim/50 bg-sim/10" : "border-warn/40 bg-warn/10"}`}>
          <div className="flex items-center justify-between">
            <span className="text-sm font-semibold">
              {issue.simulated && <span className="mr-1.5 rounded bg-sim/20 px-1.5 py-0.5 text-[10px] font-bold text-sim">SIMULATED</span>}
              {issue.title}
            </span>
            <span className="text-[11px] text-fog-dim">{STATUS[issue.status]}</span>
          </div>
          <p className="mt-0.5 text-xs text-fog-dim">
            {issue.kind === "low_disk"
              ? `${Number(m.disk_percent).toFixed(0)}% used · ${Number(m.free_percent).toFixed(0)}% free on ${m.drive}`
              : `RAM ${Number(m.ram_percent).toFixed(0)}% for ${m.samples} checks in a row`}
            {issue.simulated ? " (simulated reading)" : ""}
          </p>
        </div>
      )}

      <div className="flex-1 space-y-2 overflow-y-auto px-3 py-3" aria-live="polite">
        {p.messages.length === 0 && <p className="pt-6 text-center text-sm text-fog-dim">Hi — ask me about your device, or wait for me to flag something.</p>}
        {p.messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
            <div className={`max-w-[88%] whitespace-pre-wrap rounded-2xl px-3 py-2 text-sm leading-snug ${msg.role === "user" ? "bg-companion/20" : "bg-ink-800"}`}>{msg.content}</div>
          </div>
        ))}
        {issue?.status === "executing" && (
          <div className="rounded-xl bg-ink-800 p-3 text-xs text-fog-dim">
            <div className="mb-1.5">{p.progress?.message ?? "Starting…"}</div>
            <div className="h-1.5 rounded-full bg-ink-700"><div className="h-1.5 rounded-full bg-companion transition-[width] duration-500" style={{ width: `${p.progress?.pct ?? 5}%` }} /></div>
          </div>
        )}
        {issue?.result && (issue.status === "resolved" || issue.status === "failed") && (
          <div className={`rounded-xl border p-3 text-sm ${issue.status === "resolved" ? "border-good/50 bg-good/10" : "border-warn/50 bg-warn/10"}`}>
            <p className="text-xs font-semibold">{issue.result.simulated ? "SIMULATED result" : "Result"} · {issue.status === "resolved" ? "Issue resolved" : "Not fully resolved"}</p>
            <p className="mt-1">{issue.result.summary}</p>
          </div>
        )}
        <div ref={endRef} />
      </div>

      {issue?.status === "awaiting_approval" && <ProposalCard issue={issue} busy={p.busy} onApprove={p.onApprove} onReject={p.onReject} onPropose={p.onPropose} />}
      {p.error && <p role="alert" className="mx-3 mb-2 rounded-lg bg-crit/10 px-3 py-2 text-xs text-crit">{p.error}</p>}

      <div className="flex gap-1.5 overflow-x-auto px-3 pb-2">
        {chips(issue).map((c) => (
          <button key={c} disabled={p.busy} onClick={() => p.onSend(c)} className="shrink-0 rounded-full border border-ink-600 px-3 py-1 text-xs text-fog-dim hover:bg-ink-800 disabled:opacity-50">{c}</button>
        ))}
      </div>
      <form onSubmit={submit} className="flex gap-2 border-t border-ink-700 p-3">
        <input value={text} onChange={(e) => setText(e.target.value)} placeholder="Ask or change the plan…" maxLength={2000}
          className="flex-1 rounded-lg bg-ink-800 px-3 py-2 text-sm placeholder:text-fog-faint" />
        <button type="submit" disabled={p.busy || !text.trim()} className="rounded-lg bg-companion px-4 py-2 text-sm font-semibold text-ink-950 disabled:opacity-40">Send</button>
      </form>
    </div>
  );
}
