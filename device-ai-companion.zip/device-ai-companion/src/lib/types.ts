export interface Battery { available: boolean; percent: number | null; plugged: boolean | null; secs_left: number | null; health_percent: number | null }
export interface Sample {
  timestamp: string; simulated: boolean; cpu_percent: number; ram_percent: number; ram_used_bytes: number; ram_total_bytes: number;
  disk_path: string; disk_percent: number; disk_free_percent: number; disk_free_bytes: number; disk_total_bytes: number; battery: Battery;
}
export interface Overlay { kind: "low_disk" | "high_memory"; label: "SIMULATED"; disk_percent: number | null; disk_free_percent: number | null; ram_percent: number | null; resolved: boolean }
export interface AiStatus { available: boolean; mode: "ollama" | "offline"; model: string; detail: string }
export type Level = "good" | "warning" | "critical";
export interface Payload {
  telemetry: Sample | null;
  summaries: { cpu: string; ram: string; disk: string; battery: string } | null;
  summaries_source: "ai" | "rules";
  overall: { status: Level; label: string; summary: string } | null;
  simulation: Overlay | null; ai: AiStatus; active_issue: Issue | null; last_refreshed: string | null; interval_seconds: number;
}
export interface Candidate { name: string; display_name: string; pid: number; memory_mb: number; memory_percent: number }
export interface Preview {
  kind: "disk" | "memory"; simulated: boolean; summary: string; risk: string;
  file_count?: number; total_bytes?: number; min_age_days?: number; folders?: string[]; examples?: { path: string; size: number }[];
  candidates?: Candidate[]; selected?: Candidate;
}
export interface Proposal { proposal_id: string; action: string; params: Record<string, unknown>; preview: Preview; simulated: boolean }
export interface Result { simulated: boolean; executed: boolean; success: boolean; summary: string; details: Record<string, unknown> }
export type IssueStatus = "detected" | "awaiting_approval" | "executing" | "resolved" | "failed" | "rejected";
export interface Issue {
  id: string; kind: "low_disk" | "high_memory"; title: string; severity: string; simulated: boolean; status: IssueStatus;
  metric: Record<string, number | string>; explanation: string | null; proposal: Proposal | null; result: Result | null;
  context: { exclude_apps?: string[] } | null; created_at: string; updated_at: string;
}
export interface Message { id: number; issue_id: string | null; role: "user" | "assistant"; content: string; simulated: boolean; ts: string }
export type WsEvent =
  | { type: "telemetry"; data: Payload }
  | { type: "issue_alert" | "issue_updated"; issue: Issue }
  | { type: "chat_message"; message: Message }
  | { type: "remediation_status"; issue_id: string; status: string; progress: number; message: string; simulated: boolean }
  | { type: "demo_reset" };
