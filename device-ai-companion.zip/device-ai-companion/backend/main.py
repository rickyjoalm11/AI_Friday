"""FastAPI app: REST + WebSocket glue around the modules. Binds to localhost; token auth for API consumers."""
import asyncio
import hmac
import os
import threading
from contextlib import asynccontextmanager

import psutil
from fastapi import Body, Depends, FastAPI, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware

from . import telemetry
from .ai_service import AIService
from .config import Settings, data_dir
from .database import Database
from .detection import DetectionEngine
from .models import ApproveRequest, ChatRequest, ProposeRequest
from .remediation import RealRemediationExecutor
from .simulation import SimulationManager, SimulationRemediationExecutor
from .websocket_manager import WebSocketManager
from .workflow import IssueWorkflow, WorkflowError

VERSION = "1.0.0"
TOKEN = os.environ.get("DAC_TOKEN", "")
HOST = os.environ.get("DAC_HOST", "127.0.0.1")
LOOPBACK = HOST in ("127.0.0.1", "localhost", "::1")


def check_startup_security():
    if not LOOPBACK and not TOKEN:
        raise RuntimeError("Refusing to bind to a non-local address without DAC_TOKEN set.")


def _token_ok(candidate: str) -> bool:
    return (not TOKEN) or hmac.compare_digest(candidate or "", TOKEN)


def require_auth(request: Request):
    h = request.headers.get("authorization", "")
    if not _token_ok(h[7:] if h.lower().startswith("bearer ") else ""):
        raise HTTPException(401, "Missing or invalid API token.")


class State:
    latest = None
    summaries = None
    summaries_source = "rules"
    last_sample_error = None


S = State()


@asynccontextmanager
async def lifespan(app: FastAPI):
    check_startup_security()
    settings = Settings.load()
    db = Database(str(data_dir() / "companion.db"))
    ws = WebSocketManager()
    ai = AIService(settings)
    engine = DetectionEngine(settings, db)
    sim = SimulationManager()
    wf = IssueWorkflow(db, ws, ai, engine, sim, RealRemediationExecutor(), SimulationRemediationExecutor(sim), lambda: S.latest)
    for k, v in dict(settings=settings, db=db, ws=ws, ai=ai, engine=engine, sim=sim, wf=wf).items():
        setattr(app.state, k, v)

    def payload():
        issues = db.list_issues(active_only=True)
        real = S.latest
        return {
            "telemetry": real, "summaries": S.summaries, "summaries_source": S.summaries_source,
            "overall": telemetry.overall_health(real, issues) if real else None,
            "simulation": sim.overlay_view(), "ai": ai.last_status,
            "active_issue": issues[0] if issues else None, "last_refreshed": real["timestamp"] if real else None,
            "interval_seconds": settings.sample_interval_seconds,
        }
    app.state.payload = payload
    summary_lock = asyncio.Lock()

    async def ai_summaries(sample):
        if not settings.ai_summaries or summary_lock.locked():
            return
        async with summary_lock:
            result = await ai.summarize(sample)
            if result and S.latest is sample:
                S.summaries, S.summaries_source = result, "ai"
                await ws.broadcast({"type": "telemetry", "data": payload()})

    async def run_sample():
        try:
            sample = await asyncio.to_thread(telemetry.collect)
        except Exception as e:  # never let one bad read kill the scheduler
            S.last_sample_error = str(e)
            return
        S.latest, S.summaries, S.summaries_source = sample, telemetry.rule_summaries(sample), "rules"
        await asyncio.to_thread(db.add_telemetry, sample, settings.history_limit)
        await wf.auto_resolve(sample)
        for det in engine.evaluate(sample, simulated=False):
            await wf.on_detection(det)
        await ws.broadcast({"type": "telemetry", "data": payload()})
        asyncio.create_task(ai_summaries(sample))

    app.state.run_sample = run_sample
    wf.on_real_change = run_sample

    async def scheduler():
        while True:
            await run_sample()
            await asyncio.sleep(settings.sample_interval_seconds)

    async def ai_probe():
        await ai.status()
        await ws.broadcast({"type": "telemetry", "data": payload()})

    tasks = [asyncio.create_task(scheduler()), asyncio.create_task(ai_probe())]

    parent = os.environ.get("DAC_PARENT_PID")
    if parent and parent.isdigit():  # exit if Electron dies without a clean shutdown
        def watchdog():
            import time
            while psutil.pid_exists(int(parent)):
                time.sleep(3)
            srv = getattr(app.state, "server", None)
            if srv:
                srv.should_exit = True
            else:
                os._exit(0)
        threading.Thread(target=watchdog, daemon=True).start()
    try:
        yield
    finally:
        for t in tasks:
            t.cancel()


app = FastAPI(title="Device AI Companion", version=VERSION, lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173", "http://127.0.0.1:5173", "null", "file://"],
                   allow_methods=["*"], allow_headers=["*"])
auth = [Depends(require_auth)]


@app.get("/api/health")  # public readiness probe: reveals nothing but liveness
async def health():
    return {"status": "ok", "version": VERSION, "ready": getattr(app.state, "wf", None) is not None}


@app.get("/api/telemetry", dependencies=auth)
async def get_telemetry():
    return app.state.payload()


@app.get("/api/issues", dependencies=auth)
async def get_issues(active_only: bool = False, limit: int = 50):
    return {"issues": app.state.db.list_issues(active_only, min(limit, 200))}


@app.get("/api/issues/{issue_id}", dependencies=auth)
async def get_issue(issue_id: str):
    db = app.state.db
    issue = db.get_issue(issue_id)
    if not issue:
        raise HTTPException(404, "Issue not found")
    return {"issue": issue, "messages": db.messages(issue_id), "events": db.events(issue_id)}


@app.get("/api/history", dependencies=auth)
async def get_history(limit: int = 60):
    db = app.state.db
    return {"telemetry": db.telemetry_history(min(limit, 500)),
            "issues": [i for i in db.list_issues(limit=100) if i["status"] in ("resolved", "rejected", "failed")]}


@app.get("/api/chat/messages", dependencies=auth)
async def chat_messages(issue_id: str | None = None):
    return {"messages": app.state.db.messages(issue_id)}


def _wf_call(coro_fn):
    async def run(*a, **k):
        try:
            return await coro_fn(*a, **k)
        except WorkflowError as e:
            raise HTTPException(409, str(e))
    return run


@app.post("/api/chat", dependencies=auth)
async def chat(body: ChatRequest):
    return await _wf_call(app.state.wf.chat)(body.message, body.issue_id)


@app.post("/api/issues/{issue_id}/approve", dependencies=auth)
async def approve(issue_id: str, body: ApproveRequest):
    return {"issue": await _wf_call(app.state.wf.approve)(issue_id, body.proposal_id)}


@app.post("/api/issues/{issue_id}/reject", dependencies=auth)
async def reject(issue_id: str):
    return {"issue": await _wf_call(app.state.wf.reject)(issue_id)}


@app.post("/api/issues/{issue_id}/propose", dependencies=auth)
async def propose(issue_id: str, body: ProposeRequest):
    """UI-driven plan change (e.g. picking a different app). Same validation as chat; still needs approval."""
    return {"issue": await _wf_call(app.state.wf.propose)(issue_id, body.action, body.params)}


@app.post("/api/simulate/{kind}", dependencies=auth)
async def simulate(kind: str):
    return {"issue": await _wf_call(app.state.wf.simulate)(kind)}


@app.post("/api/simulate-reset", dependencies=auth)
async def simulate_reset():
    await app.state.wf.reset_demo()
    return {"ok": True}


@app.post("/api/refresh", dependencies=auth)
async def refresh():
    await app.state.run_sample()
    return app.state.payload()


@app.get("/api/ai/status", dependencies=auth)
async def ai_status():
    return await app.state.ai.status()


@app.get("/api/config", dependencies=auth)
async def get_config():
    return app.state.settings.as_dict()


@app.put("/api/config", dependencies=auth)
async def put_config(values: dict = Body(...)):
    try:
        app.state.settings.apply(values)
    except (ValueError, TypeError) as e:
        raise HTTPException(422, str(e))
    return app.state.settings.as_dict()


@app.post("/api/shutdown", dependencies=auth)
async def shutdown():
    srv = getattr(app.state, "server", None)
    if srv:
        srv.should_exit = True
    return {"ok": True}


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    if not _token_ok(websocket.query_params.get("token", "")):
        await websocket.close(code=4401)
        return
    mgr: WebSocketManager = app.state.ws
    await mgr.connect(websocket)
    try:
        await websocket.send_json({"type": "telemetry", "data": app.state.payload()})
        while True:
            await websocket.receive_text()  # keep-alive; the UI talks to us over REST
    except WebSocketDisconnect:
        pass
    finally:
        mgr.disconnect(websocket)
