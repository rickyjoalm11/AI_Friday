"""Local AI via Ollama (Phi-4) with a deterministic offline fallback.

The model only ever returns text plus an *optional named action from the registry*. It cannot approve,
execute, or run commands; workflow.py validates every proposed action and requires fresh user approval."""
import asyncio
import json
import math
import re
import urllib.request

from .remediation import ACTIONS, expand_aliases, fmt_bytes

SYSTEM_PROMPT = """You are Device AI Companion, a calm, concise assistant inside a Windows desktop app.
You help the user understand their device's health and decide on a fix. Rules:
- Use ONLY the facts in the CONTEXT JSON. Never invent numbers. Anything with simulated=true is a SIMULATION: say "simulated" when you mention it.
- You cannot run commands, approve actions, or delete/close anything. Only the user can, by pressing the Approve button.
- If the user wants to change the plan, propose ONE action from allowed_actions with valid params. Otherwise use action "none".
- If the user says "do not close X" / "keep X", use action "close_application" with params {"exclude_apps": ["x"]}.
- If the user wants only old files cleaned, use action "cleanup_temp_files" with {"min_age_days": N}.
- If the user asks you to "resolve/fix it" or says "yes/go ahead", use action "none" and tell them to review the plan and press Approve.
- Keep replies under 90 words, plain language, no markdown.
Reply with JSON only: {"reply": "<text>", "action": "none|cleanup_temp_files|close_application", "params": {}}"""


def _extract_json(text: str):
    try:
        return json.loads(text)
    except (ValueError, TypeError):
        m = re.search(r"\{.*\}", text or "", re.S)
        if m:
            try:
                return json.loads(m.group(0))
            except ValueError:
                return None
    return None


class AIService:
    def __init__(self, settings):
        self.settings = settings
        self.last_status = {"available": False, "mode": "offline", "model": settings.ollama_model, "detail": "Not checked yet"}

    # ---- transport (stdlib only, run in a thread) ----
    def _post(self, path, payload, timeout):
        req = urllib.request.Request(self.settings.ollama_url.rstrip("/") + path, json.dumps(payload).encode(),
                                     {"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode())

    def _get(self, path, timeout):
        with urllib.request.urlopen(self.settings.ollama_url.rstrip("/") + path, timeout=timeout) as r:
            return json.loads(r.read().decode())

    async def status(self) -> dict:
        model = self.settings.ollama_model
        try:
            tags = await asyncio.to_thread(self._get, "/api/tags", 2)
            names = [m.get("name", "") for m in tags.get("models", [])]
            ok = any(n == model or n.startswith(model + ":") for n in names)
            self.last_status = {"available": ok, "mode": "ollama" if ok else "offline", "model": model,
                                "detail": f"{model} ready" if ok else f"Ollama is running but '{model}' is not installed (run: ollama pull {model})"}
        except Exception:
            self.last_status = {"available": False, "mode": "offline", "model": model,
                                "detail": "Ollama not reachable — using built-in offline replies"}
        return self.last_status

    async def _chat(self, messages, want_json, timeout=None):
        payload = {"model": self.settings.ollama_model, "messages": messages, "stream": False,
                   "options": {"temperature": 0.2, "num_predict": 400}}
        if want_json:
            payload["format"] = "json"
        try:
            r = await asyncio.to_thread(self._post, "/api/chat", payload, timeout or self.settings.ollama_timeout_seconds)
            self.last_status = {**self.last_status, "available": True, "mode": "ollama", "detail": f"{self.settings.ollama_model} ready"}
            return r["message"]["content"]
        except Exception:
            self.last_status = {**self.last_status, "available": False, "mode": "offline",
                                "detail": "Ollama not reachable — using built-in offline replies"}
            return None

    # ---- public API ----
    async def interpret(self, message: str, ctx: dict) -> dict:
        """-> {"reply": str, "action": str, "params": dict, "source": "ollama"|"offline"}"""
        det = fallback_interpret(message, ctx)
        history = [{"role": m["role"], "content": m["content"]} for m in ctx.get("history", [])[-8:]]
        user = f"CONTEXT:\n{json.dumps(ctx['llm_context'], default=str)}\n\nUSER MESSAGE:\n{message}"
        text = await self._chat([{"role": "system", "content": SYSTEM_PROMPT}, *history, {"role": "user", "content": user}], True)
        data = _extract_json(text) if text else None
        if not isinstance(data, dict) or not isinstance(data.get("reply"), str):
            return {**det, "source": "offline"}
        action = data.get("action") if data.get("action") in ACTIONS else "none"
        params = data.get("params") if isinstance(data.get("params"), dict) else {}
        # Safety net: a clear instruction the small model missed ("don't close my browser") still takes effect.
        if action == "none" and det["action"] != "none":
            action, params = det["action"], det["params"]
        return {"reply": data["reply"].strip()[:900], "action": action, "params": params, "source": "ollama"}

    async def explain(self, ctx: dict) -> str:
        prompt = ("In 2-3 short sentences, explain this device issue to a non-technical user, say what the proposed fix is, "
                  "and remind them nothing happens until they press Approve. Mention 'simulated' if simulated=true. No markdown.\n"
                  f"CONTEXT:\n{json.dumps(ctx['llm_context'], default=str)}")
        text = await self._chat([{"role": "system", "content": SYSTEM_PROMPT.split("Rules:")[0]},
                                 {"role": "user", "content": prompt}], False)
        return (text or "").strip()[:700] or fallback_explain(ctx)

    async def summarize(self, sample: dict):
        prompt = ("Write a health summary for each metric, max 12 words each, plain language. Reply JSON only: "
                  '{"cpu":"","ram":"","disk":"","battery":"","overall":""}\nDATA:' + json.dumps(
                      {k: sample[k] for k in ("cpu_percent", "ram_percent", "disk_percent", "disk_free_percent", "battery")}))
        text = await self._chat([{"role": "user", "content": prompt}], True, timeout=45)
        data = _extract_json(text) if text else None
        if isinstance(data, dict) and all(isinstance(data.get(k), str) and data[k] for k in ("cpu", "ram", "disk", "battery")):
            if not sample["battery"]["available"]:
                data["battery"] = "Not available"
            return {k: str(v)[:140] for k, v in data.items()}
        return None


# ===================== deterministic offline logic =====================
def fallback_explain(ctx: dict) -> str:
    issue, tag = ctx["issue"], ("SIMULATED: " if ctx["issue"]["simulated"] else "")
    prev = (issue.get("proposal") or {}).get("preview") or {}
    if issue["kind"] == "low_disk":
        m = issue["metric"]
        text = f"{tag}Only {m['free_percent']:.0f}% of {m['drive']} is free ({m['disk_percent']:.0f}% used)."
        if prev:
            text += f" Old temporary files are the safest thing to clear: {prev['file_count']:,} files ({fmt_bytes(prev['total_bytes'])}) are eligible."
    else:
        m = issue["metric"]
        text = f"{tag}RAM has stayed above {m['threshold_percent']:.0f}% for {m['samples']} checks in a row (now {m['ram_percent']:.0f}%)."
        c = ctx.get("candidates") or []
        if c:
            text += " Biggest closable apps: " + ", ".join(f"{x['display_name']} ({x['memory_mb']:,} MB)" for x in c[:3]) + "."
    return text + " Nothing happens until you press Approve."


def parse_age_days(m: str):
    if "old" not in m:
        return None
    hit = re.search(r"(\d+|an?|one)\s*(hour|day|week|month)s?", m)
    if not hit:
        return None
    n = 1 if hit.group(1) in ("a", "an", "one") else int(hit.group(1))
    unit = hit.group(2)
    return min(365, math.ceil(n / 24) if unit == "hour" else n * {"day": 1, "week": 7, "month": 30}[unit])


def parse_exclusions(m: str) -> list:
    apps = []
    pat = r"(?:do not|don't|dont|never|without|please don't)\s+(?:close|kill|quit|touch|stop|shut)\s+(?:down\s+)?(?:my\s+|the\s+)?([a-z0-9 ._+-]+?)(?=[.,!?;]|$|\s+(?:and|but|or)\s)"
    pat2 = r"(?:except|keep|leave|spare|protect)\s+(?:my\s+|the\s+)?([a-z0-9 ._+-]+?)(?=[.,!?;]|$|\s+(?:and|but|or|open|running|alone)\s)"
    for p in (pat, pat2):
        for g in re.findall(p, m):
            g = g.strip()
            if g and g not in ("it", "anything", "that", "this"):
                apps.append(g)
    return apps


def fallback_interpret(message: str, ctx: dict) -> dict:
    m = message.lower().strip()
    issue, sample, res = ctx.get("issue"), ctx["sample"], ctx.get("result")
    kind = issue["kind"] if issue else None
    action, params = "none", {}

    excl = parse_exclusions(m)
    days = parse_age_days(m)
    if excl and kind in (None, "high_memory"):
        action, params = "close_application", {"exclude_apps": excl}
    elif days is not None and kind in (None, "low_disk"):
        action, params = "cleanup_temp_files", {"min_age_days": days}
    elif kind == "high_memory" and not excl:
        for c in ctx.get("candidates") or []:
            nm = re.sub(r"\s*\(simulated\)", "", c["display_name"].lower())
            if re.search(r"\bclose\b.*\b" + re.escape(nm.split()[-1]) + r"\b", m):
                action, params = "close_application", {"pid": c["pid"]}
                break

    if action != "none":
        reply = "Understood — I'll adjust the plan to match."
    elif re.search(r"success|worked|did it work|was it|result", m):
        reply = res["summary"] if res else "Nothing has been run yet. Review the plan and press Approve when you're ready."
    elif re.search(r"how.*(device|pc|computer|health|doing)|status|health", m):
        b = sample["battery"]
        batt = f"{b['percent']:.0f}%" if b["available"] else "not available"
        reply = (f"CPU {sample['cpu_percent']:.0f}%, RAM {sample['ram_percent']:.0f}%, disk {sample['disk_percent']:.0f}% used, battery {batt}. "
                 + (f"There is an active issue: {issue['title']}." if issue and issue["status"] != "resolved" else "No active issues."))
        if sample.get("simulated"):
            reply = "SIMULATED readings — " + reply
    elif re.search(r"why.*(ram|memory)|(ram|memory).*(high|full|why)", m):
        c = ctx.get("candidates") or []
        reply = (f"RAM is at {sample['ram_percent']:.0f}%. Largest apps: " + ", ".join(f"{x['display_name']} ({x['memory_mb']:,} MB)" for x in c[:3]) + "."
                 if c else f"RAM is at {sample['ram_percent']:.0f}%. I don't see any closable apps using a lot of it.")
    elif re.search(r"disk|storage|space", m) and re.search(r"consum|using|what|taking|fill", m):
        prev = ((issue or {}).get("proposal") or {}).get("preview") or {}
        reply = (f"Disk is {sample['disk_percent']:.0f}% used. I found {prev['file_count']:,} old temporary files ({fmt_bytes(prev['total_bytes'])}) that are safe to remove."
                 if prev.get("kind") == "disk" else f"Disk is {sample['disk_percent']:.0f}% used. I only look at temporary files; I can't scan your documents.")
    elif re.search(r"recommend|suggest|what should|advice", m):
        prop = (issue or {}).get("proposal")
        reply = f"I recommend this: {prop['preview']['summary']} Press Approve to run it." if prop else "Nothing needs fixing right now."
    elif re.search(r"resolve|fix|go ahead|do it|^yes|approve|clean", m):
        reply = ("I can't run anything myself. Review the plan above and press Approve — or tell me what to change."
                 if issue and issue["status"] == "awaiting_approval" else "There's nothing waiting for approval right now.")
    else:
        reply = ("Ask me about your device, why RAM or disk is high, or tell me how to change the plan "
                 "(for example: \"only files older than 14 days\" or \"don't close my browser\").")
    return {"reply": reply, "action": action, "params": params}
