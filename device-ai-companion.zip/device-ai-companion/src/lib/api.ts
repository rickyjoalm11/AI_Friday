import type { Issue, Message, Payload, WsEvent } from "./types";

export interface DacBridge {
  getConfig(): Promise<{ baseUrl: string; wsUrl: string; token: string } | { error: string }>;
  openChat(issueId?: string): void;
  setChatOpen(open: boolean): void;
  dragBy(dx: number, dy: number): void;
  showDashboard(): void;
  quit(): void;
  contextMenu(): void;
  onOpenIssue(cb: (issueId: string | null) => void): () => void;
}
declare global { interface Window { dac: DacBridge } }

export class Api {
  constructor(private baseUrl: string, private token: string, private wsUrl: string) {}

  private async req<T>(method: string, path: string, body?: unknown): Promise<T> {
    const r = await fetch(this.baseUrl + path, {
      method,
      headers: { Authorization: `Bearer ${this.token}`, ...(body ? { "Content-Type": "application/json" } : {}) },
      body: body ? JSON.stringify(body) : undefined,
    });
    if (!r.ok) {
      let detail = r.statusText;
      try { detail = (await r.json()).detail ?? detail; } catch { /* keep statusText */ }
      throw new Error(typeof detail === "string" ? detail : JSON.stringify(detail));
    }
    return r.json();
  }

  telemetry = () => this.req<Payload>("GET", "/api/telemetry");
  refresh = () => this.req<Payload>("POST", "/api/refresh");
  issue = (id: string) => this.req<{ issue: Issue; messages: Message[] }>("GET", `/api/issues/${id}`);
  generalMessages = () => this.req<{ messages: Message[] }>("GET", "/api/chat/messages");
  chat = (message: string, issueId: string | null) => this.req<{ reply: string; issue: Issue | null }>("POST", "/api/chat", { message, issue_id: issueId });
  approve = (id: string, proposalId: string) => this.req<{ issue: Issue }>("POST", `/api/issues/${id}/approve`, { proposal_id: proposalId });
  reject = (id: string) => this.req<{ issue: Issue }>("POST", `/api/issues/${id}/reject`);
  propose = (id: string, action: string, params: Record<string, unknown>) =>
    this.req<{ issue: Issue }>("POST", `/api/issues/${id}/propose`, { action, params });
  simulate = (kind: "disk" | "memory") => this.req<{ issue: Issue }>("POST", `/api/simulate/${kind}`);
  resetDemo = () => this.req<{ ok: boolean }>("POST", "/api/simulate-reset");

  /** WebSocket with automatic reconnect. Returns an unsubscribe function. */
  listen(onEvent: (e: WsEvent) => void, onState: (connected: boolean) => void): () => void {
    let ws: WebSocket | null = null;
    let stopped = false;
    const open = () => {
      ws = new WebSocket(this.wsUrl);
      ws.onopen = () => onState(true);
      ws.onmessage = (m) => { try { onEvent(JSON.parse(m.data)); } catch { /* ignore */ } };
      ws.onclose = () => { onState(false); if (!stopped) setTimeout(open, 2000); };
      ws.onerror = () => ws?.close();
    };
    open();
    return () => { stopped = true; ws?.close(); };
  }
}

export async function connect(): Promise<Api> {
  const cfg = await window.dac.getConfig();
  if ("error" in cfg) throw new Error(cfg.error);
  return new Api(cfg.baseUrl, cfg.token, cfg.wsUrl);
}
