"""Request bodies for the REST API (pydantic)."""
from typing import Any, Dict, Optional

from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=2000)
    issue_id: Optional[str] = None


class ApproveRequest(BaseModel):
    proposal_id: str = Field(min_length=1, max_length=64)


class ProposeRequest(BaseModel):
    action: str = Field(max_length=64)
    params: Dict[str, Any] = {}
