"""Tiny broadcast hub for connected UI clients (dashboard window, floating chat window, Electron main)."""
import asyncio


class WebSocketManager:
    def __init__(self):
        self.clients = set()

    async def connect(self, ws):
        await ws.accept()
        self.clients.add(ws)

    def disconnect(self, ws):
        self.clients.discard(ws)

    async def broadcast(self, message: dict):
        dead = []
        for ws in list(self.clients):
            try:
                await asyncio.wait_for(ws.send_json(message), timeout=5)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.disconnect(ws)
