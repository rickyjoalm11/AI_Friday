import { barClass, levelClass } from "../lib/format";

export interface SimGhost { pct: number; text: string; resolved: boolean }
interface Props {
  title: string;
  value: string;            // big number, e.g. "42%" or "Not available"
  detail?: string;          // small line under the value
  pct: number | null;       // bar fill, null = no bar
  level: "good" | "warning" | "critical" | "unknown";
  summary: string;          // AI (or rule-based) health summary
  aiWritten: boolean;
  ghost?: SimGhost | null;  // simulated reading, always drawn separately from the real one
}

export default function ResourceCard({ title, value, detail, pct, level, summary, aiWritten, ghost }: Props) {
  return (
    <section className={`rounded-2xl bg-ink-900 p-5 border ${ghost ? "border-sim/50 border-dashed" : "border-ink-700"}`} aria-label={title}>
      <div className="flex items-baseline justify-between">
        <h2 className="text-sm font-medium text-fog-dim">{title}</h2>
        <span className={`text-xs ${levelClass[level]}`}>{level === "unknown" ? "" : level === "good" ? "Good" : level === "warning" ? "Watch" : "High"}</span>
      </div>
      <div className={`mt-2 font-semibold tracking-tight ${value.length > 6 ? "text-2xl text-fog-dim" : "text-4xl"}`}>{value}</div>
      {detail && <div className="mt-0.5 text-xs text-fog-faint">{detail}</div>}

      {pct !== null && (
        <div className="relative mt-4 h-2 rounded-full bg-ink-700" role="progressbar" aria-valuenow={Math.round(pct)} aria-valuemin={0} aria-valuemax={100}>
          <div className={`h-2 rounded-full transition-[width] duration-700 ${barClass[level]}`} style={{ width: `${Math.min(100, pct)}%` }} />
          {ghost && (
            <div className="absolute -top-1.5 h-5 w-0 border-l-2 border-dashed border-sim transition-[left] duration-700" style={{ left: `${Math.min(100, ghost.pct)}%` }} />
          )}
        </div>
      )}
      {ghost && (
        <p className="mt-2 text-xs text-sim">
          <span className="mr-1.5 rounded bg-sim/15 px-1.5 py-0.5 font-semibold">SIMULATED</span>
          {ghost.text}{ghost.resolved ? " (after simulated fix)" : ""}
        </p>
      )}
      <p className="mt-3 text-sm leading-snug text-fog">{summary}</p>
      <p className="mt-1 text-[11px] text-fog-faint">{aiWritten ? "Written by Phi-4 on this device" : "Built-in summary"}</p>
    </section>
  );
}
