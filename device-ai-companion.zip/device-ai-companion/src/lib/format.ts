export const fmtBytes = (n: number) => {
  const u = ["B", "KB", "MB", "GB", "TB"]; let i = 0; let v = n;
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
  return `${v.toFixed(i < 2 ? 0 : 1)} ${u[i]}`;
};
export const fmtTime = (iso: string | null) => (iso ? new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }) : "—");
export const levelClass: Record<string, string> = { good: "text-good", warning: "text-warn", critical: "text-crit", unknown: "text-fog-dim" };
export const barClass: Record<string, string> = { good: "bg-good", warning: "bg-warn", critical: "bg-crit", unknown: "bg-ink-600" };
export const level = (v: number, warn: number, crit: number) => (v >= crit ? "critical" : v >= warn ? "warning" : "good");
