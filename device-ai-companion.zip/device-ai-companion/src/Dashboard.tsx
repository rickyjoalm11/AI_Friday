import { useCallback, useEffect, useState } from "react";
import ResourceCard from "./components/ResourceCard";
import SimulateMenu from "./components/SimulateMenu";
import { Api } from "./lib/api";
import { fmtBytes, fmtTime, level, levelClass } from "./lib/format";
import type { Payload } from "./lib/types";
import { useBackend } from "./lib/useBackend";

export default function Dashboard() {
  const { api, error } = useBackend();
  if (error) return <Splash title="The monitoring service didn't start" body={error} />;
  if (!api) return <Splash title="Starting Device AI Companion…" body="Launching the local monitoring service." />;
  return <Main api={api} />;
}

function Splash({ title, body }: { title: string; body: string }) {
  return (
    <div className="flex h-full items-center justify-center p-10 text-center">
      <div><h1 className="text-xl font-semibold">{title}</h1><p className="mt-2 max-w-md whitespace-pre-wrap text-sm text-fog-dim">{body}</p></div>
    </div>
  );
}

function Main({ api }: { api: Api }) {
  const [data, setData] = useState<Payload | null>(null);
  const [connected, setConnected] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  const reload = useCallback(() => api.telemetry().then(setData).catch(() => undefined), [api]);
  useEffect(() => {
    reload();
    return api.listen((e) => {
      if (e.type === "telemetry") setData(e.data);
      else if (e.type === "issue_alert" || e.type === "issue_updated" || e.type === "demo_reset") reload();
    }, setConnected);
  }, [api, reload]);

  // The simulated overlay expires on its own; re-poll so the dashboard returns to real-only without a manual reset.
  useEffect(() => {
    if (!data?.simulation?.resolved) return;
    const t = setInterval(reload, 5000);
    return () => clearInterval(t);
  }, [data?.simulation?.resolved, reload]);

  const fail = (e: unknown) => { setToast((e as Error).message); setTimeout(() => setToast(null), 6000); };
  // The floating icon shows the alert after a simulation; clicking it opens the chat.
  const simulate = async (k: "disk" | "memory") => { try { await api.simulate(k); await reload(); } catch (e) { fail(e); } };
  const reset = async () => { try { await api.resetDemo(); await reload(); } catch (e) { fail(e); } };
  const [refreshing, setRefreshing] = useState(false);
  const refresh = async () => { setRefreshing(true); try { setData(await api.refresh()); } catch (e) { fail(e); } finally { setRefreshing(false); } };

  const t = data?.telemetry;
  const sim = data?.simulation ?? null;
  const sums = data?.summaries;
  const ai = data?.summaries_source === "ai";
  const b = t?.battery;
  const issue = data?.active_issue ?? null;

  return (
    <div className="mx-auto flex h-full max-w-5xl flex-col gap-5 overflow-y-auto p-7">
      <header className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold tracking-tight">Device AI Companion</h1>
          <p className="mt-0.5 flex items-center gap-2 text-xs text-fog-dim">
            <span className={`inline-block h-2 w-2 rounded-full ${data?.ai.available ? "bg-good" : "bg-warn"}`} />
            {data ? (data.ai.available ? `${data.ai.model} is running on this PC` : "Offline mode — Ollama isn't reachable, using built-in replies") : "Connecting…"}
            {!connected && <span className="text-crit">· reconnecting</span>}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-xs text-fog-dim">Last refreshed {fmtTime(data?.last_refreshed ?? null)}</span>
          <button onClick={refresh} disabled={refreshing} className="rounded-lg border border-ink-600 px-3 py-2 text-sm hover:bg-ink-800 disabled:opacity-50">{refreshing ? "Checking…" : "Check now"}</button>
          <SimulateMenu onPick={simulate} onReset={reset} simActive={!!sim || !!issue?.simulated} />
          <button onClick={() => window.dac.quit()} className="text-xs text-fog-faint hover:text-fog">Quit</button>
        </div>
      </header>

      {data?.overall && (
        <div className="rounded-2xl border border-ink-700 bg-ink-900 px-6 py-5">
          <div className="flex items-baseline gap-3">
            <span className={`text-2xl font-semibold ${levelClass[data.overall.status]}`}>{data.overall.label}</span>
            <span className="text-sm text-fog-dim">Overall device health</span>
          </div>
          <p className="mt-1 text-sm text-fog">{data.overall.summary}</p>
        </div>
      )}

      {issue ? (
        <button onClick={() => window.dac.openChat(issue.id)}
          className={`flex items-center justify-between rounded-2xl border px-5 py-4 text-left ${issue.simulated ? "border-sim/60 bg-sim/10" : "border-warn/60 bg-warn/10"}`}>
          <span>
            {issue.simulated && <span className="mr-2 rounded bg-sim/20 px-1.5 py-0.5 text-xs font-semibold text-sim">SIMULATED</span>}
            <span className="font-medium">{issue.title}</span>
            <span className="ml-2 text-sm text-fog-dim">{issue.status === "awaiting_approval" ? "Waiting for your decision" : issue.status === "executing" ? "Fixing…" : issue.status === "failed" ? "Needs another step" : "Detected"}</span>
          </span>
          <span className="text-sm text-companion">Open chat</span>
        </button>
      ) : (
        <div className="rounded-2xl border border-ink-700 px-5 py-3 text-sm text-fog-dim">No active issues. I check every {Math.round((data?.interval_seconds ?? 60) / 60)} minute and will tell you if something needs attention.</div>
      )}

      {t && sums ? (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <ResourceCard title="CPU" value={`${t.cpu_percent.toFixed(0)}%`} pct={t.cpu_percent} level={level(t.cpu_percent, 75, 90)} summary={sums.cpu} aiWritten={ai} />
          <ResourceCard title="Memory" value={`${t.ram_percent.toFixed(0)}%`} detail={`${fmtBytes(t.ram_used_bytes)} of ${fmtBytes(t.ram_total_bytes)}`}
            pct={t.ram_percent} level={level(t.ram_percent, 80, 90)} summary={sums.ram} aiWritten={ai}
            ghost={sim?.ram_percent != null ? { pct: sim.ram_percent, text: `${sim.ram_percent.toFixed(0)}% used`, resolved: sim.resolved } : null} />
          <ResourceCard title={`Disk (${t.disk_path})`} value={`${t.disk_percent.toFixed(0)}%`} detail={`${t.disk_free_percent.toFixed(0)}% free · ${fmtBytes(t.disk_free_bytes)} of ${fmtBytes(t.disk_total_bytes)}`}
            pct={t.disk_percent} level={level(t.disk_percent, 80, 90)} summary={sums.disk} aiWritten={ai}
            ghost={sim?.disk_percent != null ? { pct: sim.disk_percent, text: `${sim.disk_percent.toFixed(0)}% used`, resolved: sim.resolved } : null} />
          <ResourceCard title="Battery"
            value={b?.available ? `${b.percent?.toFixed(0)}%` : "Not available"}
            detail={b?.available ? `${b.plugged ? "Plugged in" : "On battery"}${b.health_percent != null ? ` · health ${b.health_percent.toFixed(0)}%` : " · health not available"}` : undefined}
            pct={b?.available ? b.percent : null}
            level={!b?.available ? "unknown" : (b.percent ?? 100) < 15 && !b.plugged ? "critical" : (b.percent ?? 100) < 30 && !b.plugged ? "warning" : "good"}
            summary={sums.battery} aiWritten={ai && !!b?.available} />
        </div>
      ) : (
        <div className="py-16 text-center text-sm text-fog-dim">Taking the first reading…</div>
      )}

      {toast && <div role="alert" className="fixed bottom-5 left-1/2 -translate-x-1/2 rounded-xl border border-crit/50 bg-ink-800 px-4 py-3 text-sm text-crit shadow-2xl">{toast}</div>}
    </div>
  );
}
