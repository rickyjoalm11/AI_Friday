"""SQLite persistence: issues, chat messages, audit events, and *real* telemetry history only."""
import json
import sqlite3
import threading
import uuid
from datetime import datetime, timezone

JSON_COLS = ("metric", "proposal", "result", "context")
ACTIVE = ("detected", "awaiting_approval", "executing", "failed")

SCHEMA = """
CREATE TABLE IF NOT EXISTS issues(
  id TEXT PRIMARY KEY, kind TEXT NOT NULL, title TEXT NOT NULL, severity TEXT,
  simulated INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL,
  metric TEXT, explanation TEXT, proposal TEXT, result TEXT, context TEXT,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL, resolved_at TEXT);
CREATE TABLE IF NOT EXISTS messages(
  id INTEGER PRIMARY KEY AUTOINCREMENT, issue_id TEXT, role TEXT NOT NULL,
  content TEXT NOT NULL, simulated INTEGER NOT NULL DEFAULT 0, ts TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY AUTOINCREMENT, issue_id TEXT, event TEXT NOT NULL,
  detail TEXT, simulated INTEGER NOT NULL DEFAULT 0, ts TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS telemetry(
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, cpu REAL, ram REAL, disk REAL, battery REAL);
CREATE INDEX IF NOT EXISTS idx_messages_issue ON messages(issue_id);
CREATE INDEX IF NOT EXISTS idx_issues_kind ON issues(kind, simulated, status);
"""


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class Database:
    def __init__(self, path: str):
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        with self.lock:
            self.conn.executescript(SCHEMA)
            # An issue left "executing" by a crash can never finish: mark it failed.
            self.conn.execute("UPDATE issues SET status='failed', updated_at=? WHERE status='executing'", (now(),))
            self.conn.commit()

    def _q(self, sql, params=()):
        with self.lock:
            cur = self.conn.execute(sql, params)
            self.conn.commit()
            return cur

    @staticmethod
    def _issue(row):
        if row is None:
            return None
        d = dict(row)
        for c in JSON_COLS:
            d[c] = json.loads(d[c]) if d.get(c) else None
        d["simulated"] = bool(d["simulated"])
        return d

    # ---- issues
    def create_issue(self, kind, title, simulated, metric, severity="warning", context=None):
        iid = uuid.uuid4().hex[:12]
        t = now()
        self._q(
            "INSERT INTO issues(id,kind,title,severity,simulated,status,metric,context,created_at,updated_at)"
            " VALUES(?,?,?,?,?,?,?,?,?,?)",
            (iid, kind, title, severity, int(simulated), "detected", json.dumps(metric), json.dumps(context or {}), t, t),
        )
        return self.get_issue(iid)

    def get_issue(self, iid):
        with self.lock:
            return self._issue(self.conn.execute("SELECT * FROM issues WHERE id=?", (iid,)).fetchone())

    def update_issue(self, iid, **fields):
        fields["updated_at"] = now()
        if fields.get("status") == "resolved":
            fields["resolved_at"] = fields["updated_at"]
        for c in JSON_COLS:
            if c in fields and fields[c] is not None:
                fields[c] = json.dumps(fields[c])
        cols = ", ".join(f"{k}=?" for k in fields)
        self._q(f"UPDATE issues SET {cols} WHERE id=?", (*fields.values(), iid))
        return self.get_issue(iid)

    def list_issues(self, active_only=False, limit=100):
        sql = "SELECT * FROM issues"
        if active_only:
            sql += " WHERE status IN (%s)" % ",".join("?" * len(ACTIVE))
        sql += " ORDER BY created_at DESC, rowid DESC LIMIT ?"
        args = (*ACTIVE, limit) if active_only else (limit,)
        with self.lock:
            return [self._issue(r) for r in self.conn.execute(sql, args).fetchall()]

    def active_issue(self, kind, simulated):
        with self.lock:
            row = self.conn.execute(
                "SELECT * FROM issues WHERE kind=? AND simulated=? AND status IN (%s) ORDER BY rowid DESC LIMIT 1"
                % ",".join("?" * len(ACTIVE)),
                (kind, int(simulated), *ACTIVE),
            ).fetchone()
        return self._issue(row)

    def last_rejected(self, kind, simulated):
        with self.lock:
            row = self.conn.execute(
                "SELECT * FROM issues WHERE kind=? AND simulated=? AND status='rejected' ORDER BY rowid DESC LIMIT 1",
                (kind, int(simulated)),
            ).fetchone()
        return self._issue(row)

    # ---- messages / events
    def add_message(self, issue_id, role, content, simulated=False):
        t = now()
        cur = self._q("INSERT INTO messages(issue_id,role,content,simulated,ts) VALUES(?,?,?,?,?)",
                      (issue_id, role, content, int(simulated), t))
        return {"id": cur.lastrowid, "issue_id": issue_id, "role": role, "content": content,
                "simulated": simulated, "ts": t}

    def messages(self, issue_id, limit=60):
        with self.lock:
            if issue_id is None:
                rows = self.conn.execute("SELECT * FROM messages WHERE issue_id IS NULL ORDER BY id DESC LIMIT ?", (limit,))
            else:
                rows = self.conn.execute("SELECT * FROM messages WHERE issue_id=? ORDER BY id DESC LIMIT ?", (issue_id, limit))
            out = [dict(r) | {"simulated": bool(r["simulated"])} for r in rows.fetchall()]
        return list(reversed(out))

    def add_event(self, issue_id, event, detail="", simulated=False):
        self._q("INSERT INTO events(issue_id,event,detail,simulated,ts) VALUES(?,?,?,?,?)",
                (issue_id, event, detail, int(simulated), now()))

    def events(self, issue_id):
        with self.lock:
            return [dict(r) for r in self.conn.execute("SELECT * FROM events WHERE issue_id=? ORDER BY id", (issue_id,))]

    # ---- telemetry (real readings only; simulated values never reach this table)
    def add_telemetry(self, s, keep=500):
        batt = (s.get("battery") or {}).get("percent")
        self._q("INSERT INTO telemetry(ts,cpu,ram,disk,battery) VALUES(?,?,?,?,?)",
                (s["timestamp"], s["cpu_percent"], s["ram_percent"], s["disk_percent"], batt))
        self._q("DELETE FROM telemetry WHERE id NOT IN (SELECT id FROM telemetry ORDER BY id DESC LIMIT ?)", (keep,))

    def telemetry_history(self, limit=60):
        with self.lock:
            rows = self.conn.execute("SELECT ts,cpu,ram,disk,battery FROM telemetry ORDER BY id DESC LIMIT ?", (limit,))
            return list(reversed([dict(r) for r in rows.fetchall()]))

    def delete_simulated(self):
        with self.lock:
            self.conn.execute("DELETE FROM messages WHERE simulated=1 OR issue_id IN (SELECT id FROM issues WHERE simulated=1)")
            self.conn.execute("DELETE FROM events WHERE simulated=1 OR issue_id IN (SELECT id FROM issues WHERE simulated=1)")
            self.conn.execute("DELETE FROM issues WHERE simulated=1")
            self.conn.commit()
