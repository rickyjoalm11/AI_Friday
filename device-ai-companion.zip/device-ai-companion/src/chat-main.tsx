import React from "react";
import ReactDOM from "react-dom/client";
import FloatingChat from "./FloatingChat";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")!).render(<React.StrictMode><FloatingChat /></React.StrictMode>);
