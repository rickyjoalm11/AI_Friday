import asyncio
import os
import re
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path

from backend import remediation, simulation
from backend.ai_service import AIService
from backend.config import Settings
from backend.database import Database
from backend.detection import DISK, MEMORY, DetectionEngine
from backend.remediation import ActionError, RealRemediationExecutor, validate_action
from backend.simulation import SimulationManager, SimulationRemediationExecutor
from backend.workflow import IssueWorkflow, WorkflowError

REAL_SAMPLE = {
    "timestamp": "2026-01-01T00:00:00+00:00", "simulated": False, "cpu_percent": 10.0, "ram_percent": 40.0,
    "ram_used_bytes": 1, "ram_total_bytes": 16 * 2**30, "disk_path": "C:\\", "disk_percent": 50.0,
    "disk_free_percent": 50.0, "disk_free_bytes": 100, "disk_total_bytes": 200,
    "battery": {"available": False, "percent": None, "plugged": None, "secs_left": None, "health_percent": None},
}


class FakeWS:
    def __init__(self):
        self.sent = []

    async def broadcast(self, m):
        self.sent.append(m)

    def types(self):
        return [m["type"] for m in self.sent]


class OfflineAI(AIService):
    async def _chat(self, *a, **k):  # no Ollama: force the deterministic fallback
        self.last_status["mode"] = "offline"
        return None


def make_env(settings=None):
    tmp = tempfile.mkdtemp()
    s = settings or Settings()
    db = Database(os.path.join(tmp, "t.db"))
    engine = DetectionEngine(s, db)
    sim = SimulationManager()
    ws = FakeWS()
    real = RealRemediationExecutor(allowlist=[os.path.join(tmp, "allowed")])
    wf = IssueWorkflow(db, ws, OfflineAI(s), engine, sim, real, SimulationRemediationExecutor(sim, step_delay=0.0),
                       lambda: dict(REAL_SAMPLE))
    return tmp, s, db, engine, sim, ws, real, wf


def sample(**kw):
    return {**REAL_SAMPLE, **kw}


class DetectionTests(unittest.TestCase):
    def test_disk_rule_and_dedup(self):
        _, s, db, engine, *_ = make_env()
        self.assertEqual(engine.evaluate(sample(disk_free_percent=16.0, disk_percent=84.0)), [])
        d = engine.evaluate(sample(disk_free_percent=14.9, disk_percent=85.1))
        self.assertEqual([x.kind for x in d], [DISK])
        db.create_issue(DISK, "Low disk space", False, {})
        self.assertEqual(engine.evaluate(sample(disk_free_percent=5.0)), [], "active issue must suppress repeats")

    def test_memory_needs_three_consecutive(self):
        _, s, db, engine, *_ = make_env()
        hi, lo = sample(ram_percent=90.0), sample(ram_percent=50.0)
        self.assertEqual(engine.evaluate(hi), [])
        self.assertEqual(engine.evaluate(hi), [])
        self.assertEqual(engine.evaluate(lo), [])          # streak broken
        self.assertEqual(engine.evaluate(hi), [])
        self.assertEqual(engine.evaluate(hi), [])
        self.assertEqual([x.kind for x in engine.evaluate(hi)], [MEMORY])

    def test_real_and_simulated_streaks_are_separate(self):
        _, s, db, engine, *_ = make_env()
        hi = sample(ram_percent=92.0)
        engine.evaluate(hi); engine.evaluate(hi)
        self.assertEqual(engine.evaluate(hi, simulated=True), [])  # sim streak starts at 1, not 3
        self.assertEqual([x.simulated for x in engine.evaluate(hi)], [False])

    def test_thresholds_configurable(self):
        s = Settings(); s.apply({"disk_free_threshold_percent": 30, "memory_consecutive_samples": 1}, persist=False)
        _, s, db, engine, *_ = make_env(s)
        self.assertTrue(engine.evaluate(sample(disk_free_percent=25.0)))
        with self.assertRaises(ValueError):
            Settings().apply({"nope": 1}, persist=False)


class ActionValidationTests(unittest.TestCase):
    def test_registry(self):
        self.assertEqual(validate_action("cleanup_temp_files", {"min_age_days": "14", "evil": "rm -rf"}, DISK), {"min_age_days": 14})
        for bad in [("format_disk", {}, DISK), ("cleanup_temp_files", {"min_age_days": -1}, DISK),
                    ("cleanup_temp_files", {"min_age_days": 9999}, DISK), ("cleanup_temp_files", {}, MEMORY),
                    ("close_application", {"pid": "abc"}, MEMORY), ("close_application", {"pid": 0}, MEMORY)]:
            with self.assertRaises(ActionError, msg=str(bad)):
                validate_action(*bad)
        self.assertEqual(validate_action("close_application", {"exclude_apps": ["Chrome!!", "  "]}, MEMORY), {"exclude_apps": ["chrome"]})

    def test_no_force_kill_code_path(self):
        for mod in (remediation, simulation):
            src = Path(mod.__file__).read_text()
            self.assertNotRegex(src, r"\.kill\(|SIGKILL|taskkill|os\.remove|shutil\.rmtree" if mod is simulation else r"\.kill\(|SIGKILL|taskkill|rmtree")


class RealDiskTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.root = Path(self.tmp, "allowed"); self.root.mkdir()
        self.outside = Path(self.tmp, "outside"); self.outside.mkdir()
        self.ex = RealRemediationExecutor(allowlist=[str(self.root)])
        old = time.time() - 30 * 86400

        def mk(path, size=1000, mtime=old):
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(b"x" * size); os.utime(path, (mtime, mtime)); return path
        self.eligible = [mk(self.root / "a.tmp"), mk(self.root / "sub" / "b.log", 2000)]
        self.keep = {
            "recent": mk(self.root / "recent.tmp", mtime=time.time() - 60),
            "week_old": mk(self.root / "week.tmp", mtime=time.time() - 3 * 86400),
            "doc": mk(self.root / "report.docx"), "exe": mk(self.root / "setup.exe"),
            "outside": mk(self.outside / "o.tmp"), "mei": mk(self.root / "_MEI123" / "x.tmp"),
        }
        try:
            os.symlink(self.outside, self.root / "link"); self.has_link = True
        except OSError:
            self.has_link = False

    def test_preview_and_execute(self):
        pv = self.ex.preview("p1", "cleanup_temp_files", {"min_age_days": 7})
        self.assertEqual(pv["file_count"], 2); self.assertEqual(pv["total_bytes"], 3000)
        prog = []
        res = self.ex.execute("p1", "cleanup_temp_files", {"min_age_days": 7}, lambda p, m: prog.append(p))
        self.assertTrue(res["executed"]); self.assertEqual(res["details"]["files_deleted"], 2)
        self.assertEqual(res["details"]["bytes_deleted"], 3000)
        for f in self.eligible: self.assertFalse(f.exists())
        for name, f in self.keep.items(): self.assertTrue(f.exists(), name + " must survive")
        self.assertIn("disk_percent", res["metrics_after"])

    def test_age_filter_is_respected(self):
        pv = self.ex.preview("p", "cleanup_temp_files", {"min_age_days": 1})
        self.assertEqual(pv["file_count"], 3)   # now includes the 3-day-old file
        with self.assertRaises(ActionError):               # nothing older than 60 days -> refuse, don't pretend
            self.ex.preview("p", "cleanup_temp_files", {"min_age_days": 60})

    def test_revalidation_skips_changed_files(self):
        self.ex.preview("p2", "cleanup_temp_files", {"min_age_days": 7})
        self.eligible[0].write_bytes(b"changed after approval")   # modified -> must not be deleted
        res = self.ex.execute("p2", "cleanup_temp_files", {"min_age_days": 7}, lambda p, m: None)
        self.assertTrue(self.eligible[0].exists()); self.assertFalse(self.eligible[1].exists())
        self.assertEqual(res["details"]["files_deleted"], 1)

    def test_symlink_not_followed(self):
        if not self.has_link: self.skipTest("no symlink support")
        self.ex.preview("p3", "cleanup_temp_files", {"min_age_days": 7})
        self.ex.execute("p3", "cleanup_temp_files", {"min_age_days": 7}, lambda p, m: None)
        self.assertTrue(self.keep["outside"].exists())

    def test_unknown_proposal_refused(self):
        with self.assertRaises(ActionError):
            self.ex.execute("nope", "cleanup_temp_files", {"min_age_days": 7}, lambda p, m: None)


@unittest.skipIf(os.name == "nt", "uses POSIX sleep/SIGTERM to emulate a closable app")
class RealMemoryTests(unittest.TestCase):
    def test_identity_and_graceful_close(self):
        ex = RealRemediationExecutor(allowlist=[tempfile.mkdtemp()])
        proc = subprocess.Popen(["sleep", "60"])
        threading.Thread(target=proc.wait, daemon=True).start()   # reap so it doesn't linger as a zombie
        import psutil
        ct = psutil.Process(proc.pid).create_time()
        sel = {"name": "sleep", "display_name": "Sleep", "pid": proc.pid, "create_time": ct, "procs": [[proc.pid, ct]],
               "memory_mb": 1, "memory_percent": 0.0}
        ex._remember("bad", {"selected": {**sel, "create_time": ct - 500, "procs": [[proc.pid, ct - 500]]}})
        with self.assertRaises(ActionError):                         # identity mismatch -> nothing closed
            ex.execute("bad", "close_application", {}, lambda p, m: None)
        self.assertIsNone(proc.poll())
        ex._remember("ok", {"selected": sel})
        res = ex.execute("ok", "close_application", {}, lambda p, m: None)
        self.assertTrue(res["executed"], res["summary"])

    def test_candidates_exclude_self_and_protected(self):
        ex = RealRemediationExecutor(allowlist=[tempfile.mkdtemp()])
        names = [c["name"] for c in ex.list_candidates()]
        self.assertNotIn("systemd", names); self.assertNotIn("init", names)
        self.assertTrue(all(c["pid"] != os.getpid() for c in ex.list_candidates(limit=50)))


class WorkflowTests(unittest.IsolatedAsyncioTestCase):
    async def test_disk_simulation_end_to_end(self):
        tmp, s, db, engine, sim, ws, real, wf = make_env()
        canary = Path(tmp, "allowed", "canary.tmp"); canary.parent.mkdir(); canary.write_text("real")
        os.utime(canary, (1, 1))
        before = db.telemetry_history()
        issue = await wf.simulate("disk")
        self.assertTrue(issue["simulated"]); self.assertEqual(issue["metric"]["disk_percent"], 95.0)
        self.assertEqual(issue["status"], "awaiting_approval"); self.assertIn("issue_alert", ws.types())
        self.assertIn("SIMULATED", issue["proposal"]["preview"]["summary"])
        self.assertTrue(any("SIMULATED" in m["content"] for m in db.messages(issue["id"])))
        first = issue["proposal"]["proposal_id"]
        # user modifies the recommendation through chat -> NEW proposal, needs NEW approval
        r = await wf.chat("Can you clean only files older than 30 days?", issue["id"])
        issue = r["issue"]; second = issue["proposal"]["proposal_id"]
        self.assertNotEqual(first, second); self.assertEqual(issue["proposal"]["params"]["min_age_days"], 30)
        self.assertEqual(issue["status"], "awaiting_approval")
        with self.assertRaises(WorkflowError): await wf.approve(issue["id"], first)       # stale approval refused
        # chat can never approve
        r = await wf.chat("Yes, go ahead and resolve this issue", issue["id"])
        self.assertEqual(db.get_issue(issue["id"])["status"], "awaiting_approval")
        await wf.approve(issue["id"], second); await wf.join(issue["id"])
        done = db.get_issue(issue["id"])
        self.assertEqual(done["status"], "resolved", done["result"]); self.assertTrue(done["result"]["simulated"])
        self.assertLess(sim.overlay_view()["disk_percent"], 95.0); self.assertTrue(sim.overlay_view()["resolved"])
        self.assertTrue(canary.exists(), "simulation must not touch real files")
        self.assertEqual(db.telemetry_history(), before, "simulation must not write telemetry")
        self.assertIn(done["id"], [i["id"] for i in db.list_issues()])
        self.assertTrue(any(e["event"] == "approved" for e in db.events(done["id"])))
        # duplicate approval is refused
        with self.assertRaises(WorkflowError): await wf.approve(done["id"], second)
        await wf.reset_demo()
        self.assertEqual(db.list_issues(), []); self.assertIsNone(sim.overlay_view()); self.assertIn("demo_reset", ws.types())

    async def test_memory_simulation_end_to_end(self):
        tmp, s, db, engine, sim, ws, real, wf = make_env()
        issue = await wf.simulate("memory")
        self.assertEqual(issue["kind"], MEMORY); self.assertEqual(issue["metric"]["samples"], 3)
        self.assertEqual(issue["proposal"]["preview"]["selected"]["name"], "chrome")
        r = await wf.chat("Do not close my browser.", issue["id"])
        issue = r["issue"]
        self.assertNotEqual(issue["proposal"]["preview"]["selected"]["name"], "chrome")
        self.assertIn("browser", issue["context"]["exclude_apps"])  # alias expands to chrome/edge/firefox/... at filter time
        self.assertEqual(issue["status"], "awaiting_approval")
        await wf.approve(issue["id"], issue["proposal"]["proposal_id"]); await wf.join(issue["id"])
        done = db.get_issue(issue["id"])
        self.assertEqual(done["status"], "resolved", done["result"])
        self.assertLessEqual(sim.overlay_view()["ram_percent"], 85.0)
        self.assertIn("remediation_status", ws.types())

    async def test_reject_then_reopen_and_duplicate_simulation_blocked(self):
        *_, db, engine, sim, ws, real, wf = (None,) * 0, *make_env()[2:]
        issue = await wf.simulate("disk")
        with self.assertRaises(WorkflowError): await wf.simulate("disk")
        issue = await wf.reject(issue["id"]); self.assertEqual(issue["status"], "rejected")
        r = await wf.chat("Actually only files older than 14 days", issue["id"])
        self.assertEqual(r["issue"]["status"], "awaiting_approval")

    async def test_real_issue_cooldown_after_reject(self):
        tmp, s, db, engine, sim, ws, real, wf = make_env()
        i = db.create_issue(DISK, "Low disk space", False, {})
        i = wf._transition(i, "rejected")
        self.assertEqual(engine.evaluate(sample(disk_free_percent=3.0)), [])

    async def test_ai_cannot_choose_unregistered_actions(self):
        tmp, s, db, engine, sim, ws, real, wf = make_env()

        class Evil(OfflineAI):
            async def _chat(self, *a, **k):
                return '{"reply":"Deleting system32 now","action":"run_shell","params":{"cmd":"del /s C:\\\\"}}'
        wf.ai = Evil(s)
        issue = await wf.simulate("disk")
        pid = issue["proposal"]["proposal_id"]
        await wf.chat("wipe everything", issue["id"])
        after = db.get_issue(issue["id"])
        self.assertEqual(after["proposal"]["proposal_id"], pid); self.assertEqual(after["status"], "awaiting_approval")

        class BadPid(OfflineAI):
            async def _chat(self, *a, **k):
                return '{"reply":"Closing it","action":"close_application","params":{"pid":1}}'
        wf.ai = BadPid(s)
        mem = await wf.simulate("memory")
        r = await wf.chat("close pid 1", mem["id"])
        self.assertIn("couldn't turn that into a safe action", r["reply"])
        self.assertNotEqual(db.get_issue(mem["id"])["proposal"]["params"].get("pid"), 1)

    async def test_ai_interpretation_used_when_available(self):
        tmp, s, db, engine, sim, ws, real, wf = make_env()

        class Good(OfflineAI):
            async def _chat(self, *a, **k):
                self.last_status["mode"] = "ollama"
                return '{"reply":"Sure, 14 days.","action":"cleanup_temp_files","params":{"min_age_days":14}}'
        wf.ai = Good(s)
        issue = await wf.simulate("disk")
        r = await wf.chat("could you be gentler", issue["id"])
        self.assertEqual(r["issue"]["proposal"]["params"]["min_age_days"], 14)

    async def test_general_questions_and_result_question(self):
        tmp, s, db, engine, sim, ws, real, wf = make_env()
        r = await wf.chat("How is my device?")
        self.assertIn("CPU 10%", r["reply"])
        issue = await wf.simulate("memory")
        r = await wf.chat("Why is my RAM high?", issue["id"])
        self.assertIn("Chrome", r["reply"])
        await wf.approve(issue["id"], issue["proposal"]["proposal_id"]); await wf.join(issue["id"])
        r = await wf.chat("Was the remediation successful?", issue["id"])
        self.assertIn("SIMULATED", r["reply"])

    async def test_auto_resolve_real_issue(self):
        tmp, s, db, engine, sim, ws, real, wf = make_env()
        i = db.create_issue(DISK, "Low disk space", False, {})
        await wf.auto_resolve(sample(disk_free_percent=60.0))
        self.assertEqual(db.get_issue(i["id"])["status"], "resolved")


if __name__ == "__main__":
    unittest.main()
