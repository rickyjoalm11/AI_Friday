"""Real device telemetry via psutil, plus rule-based health summaries (used until/unless the AI writes them)."""
import os
import subprocess
import time
from datetime import datetime, timezone

import psutil

_health_cache = {"ts": 0.0, "value": None}


def system_drive() -> str:
    return (os.environ.get("SystemDrive", "C:") + "\\") if os.name == "nt" else "/"


def _battery_health_percent():
    """Full-charge capacity / design capacity (Windows WMI, best effort, cached 6h). None if unknown."""
    if os.name != "nt":
        return None
    if time.time() - _health_cache["ts"] < 6 * 3600:
        return _health_cache["value"]
    value = None
    script = (
        "$f=(Get-CimInstance -Namespace root/wmi -ClassName BatteryFullChargedCapacity -ErrorAction Stop)"
        " | Select-Object -First 1 -ExpandProperty FullChargedCapacity;"
        "$d=(Get-CimInstance -Namespace root/wmi -ClassName BatteryStaticData -ErrorAction Stop)"
        " | Select-Object -First 1 -ExpandProperty DesignedCapacity;"
        "if($d -gt 0){[math]::Round(100*$f/$d,1)}"
    )
    try:
        out = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", script],
            capture_output=True, text=True, timeout=20, creationflags=0x08000000,  # CREATE_NO_WINDOW
        ).stdout.strip()
        value = min(100.0, float(out)) if out else None
    except Exception:
        value = None
    _health_cache.update(ts=time.time(), value=value)
    return value


def read_battery() -> dict:
    try:
        b = psutil.sensors_battery()
    except Exception:
        b = None
    if b is None:
        return {"available": False, "percent": None, "plugged": None, "secs_left": None, "health_percent": None}
    secs = b.secsleft if isinstance(b.secsleft, int) and b.secsleft > 0 else None
    return {"available": True, "percent": round(b.percent, 1), "plugged": b.power_plugged,
            "secs_left": secs, "health_percent": _battery_health_percent()}


def collect() -> dict:
    """One real reading. Blocks ~1s (CPU sampling), so call from a worker thread."""
    cpu = psutil.cpu_percent(interval=1.0)
    vm = psutil.virtual_memory()
    du = psutil.disk_usage(system_drive())
    return {
        "timestamp": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "simulated": False,
        "cpu_percent": round(cpu, 1),
        "ram_percent": round(vm.percent, 1),
        "ram_used_bytes": vm.used,
        "ram_total_bytes": vm.total,
        "disk_path": system_drive(),
        "disk_percent": round(du.percent, 1),
        "disk_free_percent": round(100 - du.percent, 1),
        "disk_free_bytes": du.free,
        "disk_total_bytes": du.total,
        "battery": read_battery(),
    }


# ---- rule-based summaries -------------------------------------------------------------
def _level(value, warn, crit):
    return "critical" if value >= crit else "warning" if value >= warn else "good"


def card_levels(s: dict) -> dict:
    b = s["battery"]
    batt = "unknown"
    if b["available"]:
        batt = "good" if b["percent"] >= 30 or b["plugged"] else "warning" if b["percent"] >= 15 else "critical"
        if b.get("health_percent") is not None and b["health_percent"] < 60:
            batt = "warning" if batt == "good" else batt
    return {
        "cpu": _level(s["cpu_percent"], 75, 90),
        "ram": _level(s["ram_percent"], 80, 90),
        "disk": _level(s["disk_percent"], 80, 90),
        "battery": batt,
    }


def rule_summaries(s: dict) -> dict:
    lv = card_levels(s)
    cpu = {"good": "Plenty of headroom right now.", "warning": "Busy, but still responsive.",
           "critical": "Heavily loaded — apps may feel slow."}[lv["cpu"]]
    ram = {"good": "Memory is comfortable.", "warning": "Getting full; heavy apps may slow down.",
           "critical": "Nearly full — close something soon."}[lv["ram"]]
    disk = {"good": f"{s['disk_free_percent']:.0f}% free on {s['disk_path']}.",
            "warning": f"Only {s['disk_free_percent']:.0f}% free — worth a cleanup.",
            "critical": f"Only {s['disk_free_percent']:.0f}% free — clean up now."}[lv["disk"]]
    b = s["battery"]
    if not b["available"]:
        batt = "Not available"
    else:
        state = "plugged in" if b["plugged"] else "on battery"
        health = f", health {b['health_percent']:.0f}%" if b.get("health_percent") is not None else ""
        batt = f"{b['percent']:.0f}% and {state}{health}."
    return {"cpu": cpu, "ram": ram, "disk": disk, "battery": batt}


def overall_health(s: dict, active_issues: list) -> dict:
    real_active = [i for i in active_issues if not i["simulated"]]
    levels = [v for v in card_levels(s).values() if v != "unknown"]
    if real_active or "critical" in levels:
        status, label = "critical" if "critical" in levels else "warning", "Needs attention"
    elif "warning" in levels:
        status, label = "warning", "Fair"
    else:
        status, label = "good", "Healthy"
    if real_active:
        text = f"{len(real_active)} active issue{'s' if len(real_active) > 1 else ''}: {real_active[0]['title']}."
    elif status == "good":
        text = "Everything looks normal. I'm checking again every minute."
    else:
        text = "Resources are getting tight, but no rule has triggered yet."
    return {"status": status, "label": label, "summary": text}
