"""Simulation: synthetic samples for the detection engine + a SimulationRemediationExecutor.

Isolation guarantees: this module never deletes files or terminates processes, never writes to the telemetry
table, and its overlay is exposed *next to* real telemetry, never merged into it."""
import copy
import time

from .detection import DISK, MEMORY
from .remediation import ActionError, expand_aliases, fmt_bytes

GB = 2**30
SIM_DISK_TOTAL = 256 * GB
SIM_RAM_TOTAL = 16 * GB
SIM_CLEANUP_BYTES = 52 * GB          # what a 0-day cleanup would "find"
SIM_FILE_COUNT = 1284
SIM_PROCS = [  # (name, display, pid, MB)  -- all fictional
    ("chrome", "Google Chrome (simulated)", 91001, 3480),
    ("teams", "Microsoft Teams (simulated)", 91002, 2460),
    ("code", "VS Code (simulated)", 91003, 1950),
    ("slack", "Slack (simulated)", 91004, 1430),
    ("spotify", "Spotify (simulated)", 91005, 1310),
]
OVERLAY_LINGER_SECONDS = 45


def _fraction(days: int) -> float:
    return 1 / (1 + days / 60)


class SimulationManager:
    def __init__(self):
        self.overlay = None
        self._closed = set()

    def _base(self, real) -> dict:
        s = copy.deepcopy(real) if real else {
            "timestamp": "", "cpu_percent": 12.0, "ram_percent": 40.0, "ram_used_bytes": 0, "ram_total_bytes": SIM_RAM_TOTAL,
            "disk_path": "C:\\", "disk_percent": 50.0, "disk_free_percent": 50.0, "disk_free_bytes": 0,
            "disk_total_bytes": SIM_DISK_TOTAL, "battery": {"available": False}}
        s["simulated"] = True
        return s

    # ---- synthetic samples (fed to the real DetectionEngine) ----
    def disk_samples(self, real) -> list:
        s = self._base(real)
        s.update(disk_percent=95.0, disk_free_percent=5.0, disk_total_bytes=SIM_DISK_TOTAL,
                 disk_free_bytes=int(SIM_DISK_TOTAL * 0.05))
        self.overlay = {"kind": DISK, "label": "SIMULATED", "disk_percent": 95.0, "disk_free_percent": 5.0,
                        "ram_percent": None, "resolved": False, "expires_at": None}
        return [s]

    def memory_samples(self, real, n=3) -> list:
        s = self._base(real)
        s.update(ram_percent=92.0, ram_total_bytes=SIM_RAM_TOTAL, ram_used_bytes=int(SIM_RAM_TOTAL * 0.92))
        self._closed.clear()
        self.overlay = {"kind": MEMORY, "label": "SIMULATED", "disk_percent": None, "disk_free_percent": None,
                        "ram_percent": 92.0, "resolved": False, "expires_at": None}
        return [copy.deepcopy(s) for _ in range(n)]

    # ---- overlay ----
    def overlay_view(self):
        o = self.overlay
        if o and o["expires_at"] and time.time() > o["expires_at"]:
            self.overlay = o = None
        return o

    def apply_result(self, metrics_after: dict, resolved: bool):
        if not self.overlay:
            return
        if "disk_percent" in metrics_after:
            self.overlay["disk_percent"] = metrics_after["disk_percent"]
            self.overlay["disk_free_percent"] = metrics_after["disk_free_percent"]
        if "ram_percent" in metrics_after:
            self.overlay["ram_percent"] = metrics_after["ram_percent"]
        self.overlay["resolved"] = resolved
        self.overlay["expires_at"] = time.time() + OVERLAY_LINGER_SECONDS

    def reset(self):
        self.overlay = None
        self._closed.clear()

    def mark_closed(self, pid):
        self._closed.add(pid)

    def closed(self):
        return set(self._closed)


class SimulationRemediationExecutor:
    """Same interface as RealRemediationExecutor; only does arithmetic and sleeps."""
    simulated = True

    def __init__(self, manager: SimulationManager, get_issue_metric=None, step_delay=0.6):
        self.mgr = manager
        self.step_delay = step_delay
        self._plans = {}

    def list_candidates(self, exclude_apps=(), limit=5) -> list:
        tokens = expand_aliases(exclude_apps)
        out = []
        for name, disp, pid, mb in SIM_PROCS:
            if pid in self.mgr.closed() or any(t in name for t in tokens):
                continue
            out.append({"name": name, "display_name": disp, "pid": pid, "create_time": 0.0, "procs": [[pid, 0.0]],
                        "memory_mb": mb, "memory_percent": round(100 * mb * 2**20 / SIM_RAM_TOTAL, 1)})
        return out[:limit]

    def preview(self, proposal_id, action, params, exclude_apps=()) -> dict:
        if action == "cleanup_temp_files":
            days = params["min_age_days"]
            f = _fraction(days)
            count, size = int(SIM_FILE_COUNT * f), int(SIM_CLEANUP_BYTES * f)
            self._plans[proposal_id] = {"size": size, "count": count}
            names = ["setup_cache_0042.tmp", "crashdump_8f3a.dmp", "update_stage.log", "render_cache.cache", "old_installer.bak"]
            return {
                "kind": "disk", "simulated": True, "file_count": count, "total_bytes": size, "min_age_days": days,
                "folders": ["(simulated) C:\\Users\\demo\\AppData\\Local\\Temp"],
                "examples": [{"path": f"(simulated) …\\Temp\\{n}", "size": int(size / 9 / (i + 1))} for i, n in enumerate(names)],
                "summary": f"SIMULATED: delete {count:,} temporary files older than {days} day(s), about {fmt_bytes(size)}.",
                "risk": "Simulation only — no real files are touched.",
            }
        if action == "close_application":
            cands = self.list_candidates(exclude_apps)
            if not cands:
                raise ActionError("No eligible simulated applications left to close.")
            pid = params.get("pid")
            sel = next((c for c in cands if c["pid"] == pid), None) if pid else cands[0]
            if sel is None:
                raise ActionError("That is not an eligible simulated application.")
            self._plans[proposal_id] = {"selected": sel}
            return {
                "kind": "memory", "simulated": True, "candidates": cands, "selected": sel,
                "summary": f"SIMULATED: ask {sel['display_name']} to close (frees about {sel['memory_mb']:,} MB, "
                           f"{sel['memory_percent']}% of RAM).",
                "risk": "Simulation only — no real process is touched. A real close could lose unsaved work.",
            }
        raise ActionError("Unsupported action.")

    def execute(self, proposal_id, action, params, progress) -> dict:
        plan = self._plans.get(proposal_id)
        if plan is None:
            raise ActionError("This preview has expired. Ask me for a fresh proposal.")
        steps = ["Re-checking approved items…", "Working…", "Measuring the result…"]
        for i, msg in enumerate(steps):
            progress(15 + i * 30, "SIMULATED: " + msg)
            time.sleep(self.step_delay)
        o = self.mgr.overlay or {}
        if action == "cleanup_temp_files":
            total_used = SIM_DISK_TOTAL * (o.get("disk_percent", 95.0) / 100)
            used_after = max(0.0, total_used - plan["size"])
            pct = round(100 * used_after / SIM_DISK_TOTAL, 1)
            return {"simulated": True, "executed": True,
                    "summary": f"SIMULATED: cleaned {plan['count']:,} files and recovered {fmt_bytes(plan['size'])}. "
                               f"Disk usage went from {o.get('disk_percent', 95.0):.0f}% to {pct:.0f}%.",
                    "details": {"files_deleted": plan["count"], "bytes_deleted": plan["size"],
                                "reclaimed_bytes_measured": plan["size"], "skipped": 0},
                    "metrics_after": {"disk_percent": pct, "disk_free_percent": round(100 - pct, 1)}}
        sel = plan["selected"]
        before = o.get("ram_percent", 92.0)
        after = round(max(0.0, before - sel["memory_percent"]), 1)
        self.mgr.mark_closed(sel["pid"])
        return {"simulated": True, "executed": True,
                "summary": f"SIMULATED: {sel['display_name']} closed gracefully, freeing about {sel['memory_mb']:,} MB. "
                           f"RAM went from {before:.0f}% to {after:.0f}%.",
                "details": {"app": sel["display_name"], "ram_before": before, "ram_after": after},
                "metrics_after": {"ram_percent": after}}
