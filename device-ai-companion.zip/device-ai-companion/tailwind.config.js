/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./chat.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: { 950: "#0b1017", 900: "#111821", 800: "#18212d", 700: "#243142", 600: "#34445a" },
        fog: { DEFAULT: "#e6ecf5", dim: "#9aa9bf", faint: "#66758c" },
        companion: "#86a2ff",
        good: "#4fd6a6",
        warn: "#f3bb55",
        crit: "#ff7d7d",
        sim: "#f472b6",
      },
      fontFamily: { sans: ['"Segoe UI Variable Text"', '"Segoe UI"', "system-ui", "sans-serif"] },
    },
  },
  plugins: [],
};
