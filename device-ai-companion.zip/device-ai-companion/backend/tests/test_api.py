"""API smoke test. Needs: pip install -r requirements-dev.txt (skipped automatically otherwise)."""
import os
import tempfile
import time
import unittest

try:
    from fastapi.testclient import TestClient
except Exception:  # fastapi/httpx missing
    TestClient = None


@unittest.skipIf(TestClient is None, "fastapi/httpx not installed")
class ApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        os.environ["DAC_DATA_DIR"] = tempfile.mkdtemp()
        os.environ["DAC_TOKEN"] = "secret"
        os.environ["DAC_OLLAMA_URL"] = "http://127.0.0.1:9"   # unreachable -> offline fallback
        import backend.main as m
        m.TOKEN = "secret"
        cls.cm = TestClient(m.app)
        cls.c = cls.cm.__enter__()
        cls.h = {"Authorization": "Bearer secret"}

    @classmethod
    def tearDownClass(cls):
        cls.cm.__exit__(None, None, None)

    def test_health_public_others_need_token(self):
        self.assertEqual(self.c.get("/api/health").json()["status"], "ok")
        self.assertEqual(self.c.get("/api/telemetry").status_code, 401)
        self.assertEqual(self.c.get("/api/telemetry", headers={"Authorization": "Bearer nope"}).status_code, 401)

    def test_real_telemetry(self):
        for _ in range(30):
            t = self.c.get("/api/telemetry", headers=self.h).json()
            if t["telemetry"]:
                break
            time.sleep(0.5)
        self.assertFalse(t["telemetry"]["simulated"])
        self.assertIn("cpu_percent", t["telemetry"])
        self.assertEqual(set(t["summaries"]), {"cpu", "ram", "disk", "battery"})
        self.assertIn("telemetry", self.c.get("/api/history", headers=self.h).json())

    def test_simulate_disk_flow(self):
        h = self.h
        r = self.c.post("/api/simulate/disk", headers=h); self.assertEqual(r.status_code, 200, r.text)
        issue = r.json()["issue"]; self.assertTrue(issue["simulated"])
        r = self.c.post("/api/chat", headers=h, json={"message": "only files older than 14 days", "issue_id": issue["id"]})
        pid = r.json()["issue"]["proposal"]["proposal_id"]
        self.assertEqual(self.c.post(f"/api/issues/{issue['id']}/approve", headers=h, json={"proposal_id": "stale"}).status_code, 409)
        self.assertEqual(self.c.post(f"/api/issues/{issue['id']}/approve", headers=h, json={"proposal_id": pid}).status_code, 200)
        for _ in range(30):
            got = self.c.get(f"/api/issues/{issue['id']}", headers=h).json()["issue"]
            if got["status"] != "executing":
                break
            time.sleep(0.5)
        self.assertEqual(got["status"], "resolved")
        self.assertEqual(self.c.post("/api/simulate-reset", headers=h).status_code, 200)

    def test_websocket_requires_token(self):
        with self.assertRaises(Exception):
            with self.c.websocket_connect("/ws?token=bad"):
                pass
        with self.c.websocket_connect("/ws?token=secret") as ws:
            self.assertEqual(ws.receive_json()["type"], "telemetry")
