import { useCallback, useEffect, useRef, useState } from "react";
import ChatPanel from "./components/ChatPanel";
import type { Api } from "./lib/api";
import type { AiStatus, Issue, Message } from "./lib/types";
import { useBackend } from "./lib/useBackend";

export default function FloatingChat() {
  const { api } = useBackend();
  return api ? <Inner api={api} /> : <Bubble badge={false} onOpen={() => undefined} />;
}

function Bubble({ badge, onOpen }: { badge: boolean; onOpen: () => void }) {
  const d = useRef({ down: false, moved: false, x: 0, y: 0 });
  return (
    <div className="flex h-full w-full items-center justify-center">
      <button
        aria-label="Open Device AI Companion"
        className="relative h-14 w-14 cursor-pointer select-none rounded-full bg-gradient-to-br from-companion to-[#5b6cff] shadow-xl ring-2 ring-ink-950/40"
        onPointerDown={(e) => { e.currentTarget.setPointerCapture(e.pointerId); d.current = { down: true, moved: false, x: e.screenX, y: e.screenY }; }}
        onPointerMove={(e) => {
          const s = d.current; if (!s.down) return;
          const dx = e.screenX - s.x, dy = e.screenY - s.y;
          if (!s.moved && Math.hypot(dx, dy) < 4) return;
          s.moved = true; window.dac.dragBy(dx, dy); s.x = e.screenX; s.y = e.screenY;
        }}
        onPointerUp={() => { if (d.current.down && !d.current.moved) onOpen(); d.current.down = false; }}
        onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") onOpen(); }}
        onContextMenu={(e) => { e.preventDefault(); window.dac.contextMenu(); }}
      >
        <svg viewBox="0 0 24 24" className="mx-auto h-7 w-7 text-ink-950" fill="currentColor" aria-hidden="true">
          <path d="M12 2.5l1.9 5.1 5.1 1.9-5.1 1.9L12 16.5l-1.9-5.1L5 9.5l5.1-1.9L12 2.5zm6.5 11l.9 2.4 2.4.9-2.4.9-.9 2.4-.9-2.4-2.4-.9 2.4-.9.9-2.4z" />
        </svg>
        {badge && <span className="badge-pulse absolute -right-0.5 -top-0.5 h-4 w-4 rounded-full border-2 border-ink-950 bg-crit" aria-label="Active issue" />}
      </button>
    </div>
  );
}

function Inner({ api }: { api: Api }) {
  const [open, setOpen] = useState(false);
  const [badge, setBadge] = useState(false);
  const [issue, setIssue] = useState<Issue | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [progress, setProgress] = useState<{ pct: number; message: string } | null>(null);
  const [ai, setAi] = useState<AiStatus | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const idRef = useRef<string | null>(null);
  const openRef = useRef(false);
  openRef.current = open;

  const load = useCallback(async (id: string | null) => {
    idRef.current = id;
    try {
      if (id) { const r = await api.issue(id); setIssue(r.issue); setMessages(r.messages); }
      else { setIssue(null); setMessages((await api.generalMessages()).messages); }
    } catch { /* issue vanished (demo reset) */ setIssue(null); idRef.current = null; setMessages([]); }
    setProgress(null);
  }, [api]);

  const show = useCallback((id: string | null) => {
    setOpen(true); setBadge(false); window.dac.setChatOpen(true);
    if (id !== idRef.current || id === null) load(id ?? idRef.current);
  }, [load]);

  useEffect(() => {
    api.telemetry().then((t) => {
      setAi(t.ai);
      if (t.active_issue && t.active_issue.status === "awaiting_approval") { setBadge(true); load(t.active_issue.id); } else load(null);
    }).catch(() => undefined);
    const offIpc = window.dac.onOpenIssue((id) => show(id));
    const offWs = api.listen((e) => {
      switch (e.type) {
        case "telemetry": setAi(e.data.ai); break;
        case "issue_alert": load(e.issue.id); if (!openRef.current) setBadge(true); break;
        case "issue_updated": if (e.issue.id === idRef.current) setIssue(e.issue); break;
        case "chat_message": {
          const m = e.message;
          if ((m.issue_id ?? null) === idRef.current) setMessages((cur) => (cur.some((x) => x.id === m.id) ? cur : [...cur, m]));
          break;
        }
        case "remediation_status": if (e.issue_id === idRef.current) setProgress(e.status === "executing" ? { pct: e.progress, message: e.message } : null); break;
        case "demo_reset": setBadge(false); api.telemetry().then((t) => load(t.active_issue?.id ?? null)).catch(() => load(null)); break;
      }
    }, () => undefined);
    return () => { offIpc(); offWs(); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [api]);

  const guard = async (fn: () => Promise<unknown>) => {
    setBusy(true); setError(null);
    try { await fn(); } catch (e) { setError((e as Error).message); } finally { setBusy(false); }
  };
  const id = () => idRef.current;

  const send = (text: string) => guard(async () => { await api.chat(text, id()); await load(id()); });
  const approve = () => guard(async () => { if (issue?.proposal) setIssue((await api.approve(issue.id, issue.proposal.proposal_id)).issue); });
  const reject = () => guard(async () => { if (issue) setIssue((await api.reject(issue.id)).issue); });
  const propose = (action: string, params: Record<string, unknown>) => guard(async () => {
    if (issue) { setIssue((await api.propose(issue.id, action, params)).issue); await load(issue.id); }
  });
  const minimize = () => { setOpen(false); window.dac.setChatOpen(false); };

  if (!open) return <Bubble badge={badge} onOpen={() => show(null)} />;
  return (
    <div className="h-full p-0">
      <ChatPanel issue={issue} messages={messages} progress={progress} ai={ai} busy={busy} error={error}
        onSend={send} onApprove={approve} onReject={reject} onPropose={propose} onMinimize={minimize} />
    </div>
  );
}
