import { contextBridge, ipcRenderer } from "electron";

contextBridge.exposeInMainWorld("dac", {
  getConfig: (): Promise<{ baseUrl: string; wsUrl: string; token: string } | { error: string }> => ipcRenderer.invoke("dac:get-config"),
  openChat: (issueId?: string) => ipcRenderer.send("dac:open-chat", issueId ?? null),
  setChatOpen: (open: boolean) => ipcRenderer.send("bubble:set-open", open),
  dragBy: (dx: number, dy: number) => ipcRenderer.send("bubble:drag-by", dx, dy),
  showDashboard: () => ipcRenderer.send("dac:show-dashboard"),
  quit: () => ipcRenderer.send("dac:quit"),
  contextMenu: () => ipcRenderer.send("bubble:context-menu"),
  onOpenIssue: (cb: (issueId: string | null) => void) => {
    const h = (_: unknown, id: string | null) => cb(id);
    ipcRenderer.on("chat:open-issue", h);
    return () => ipcRenderer.removeListener("chat:open-issue", h);
  },
});
