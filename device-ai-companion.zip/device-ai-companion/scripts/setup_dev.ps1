# One-time developer setup (Windows 10/11, PowerShell). Run from the project root.
$ErrorActionPreference = "Stop"
python -m venv .venv
.\.venv\Scripts\python -m pip install --upgrade pip
.\.venv\Scripts\python -m pip install -r requirements-dev.txt
npm install
Write-Host "`nDone. Start the app with:  `$env:DAC_PYTHON = `"$PWD\.venv\Scripts\python.exe`"; npm run dev"
Write-Host "Optional AI: install Ollama from https://ollama.com then run:  ollama pull phi4"
