import type { Issue } from "../lib/types";
import { fmtBytes } from "../lib/format";

interface Props {
  issue: Issue;
  busy: boolean;
  onApprove: () => void;
  onReject: () => void;
  onPropose: (action: string, params: Record<string, unknown>) => void;
}

const AGES = [7, 14, 30, 90];

export default function ProposalCard({ issue, busy, onApprove, onReject, onPropose }: Props) {
  const p = issue.proposal;
  if (!p) return null;
  const pv = p.preview;
  const memory = pv.kind === "memory";
  const age = Number(p.params.min_age_days ?? 7);
  return (
    <div className={`mx-3 mb-2 rounded-xl border p-3 text-sm ${issue.simulated ? "border-sim/50 bg-sim/5" : "border-ink-600 bg-ink-800"}`}>
      <p className="text-xs font-medium text-fog-dim">Suggested fix · needs your approval</p>
      <p className="mt-1 leading-snug">{pv.summary}</p>

      {!memory && (
        <>
          <p className="mt-2 text-xs text-fog-dim">Only files older than:</p>
          <div className="mt-1 flex gap-1.5">
            {AGES.map((d) => (
              <button key={d} disabled={busy} onClick={() => d !== age && onPropose("cleanup_temp_files", { min_age_days: d })}
                className={`rounded-md px-2.5 py-1 text-xs ${d === age ? "bg-companion text-ink-950 font-semibold" : "bg-ink-700 hover:bg-ink-600"}`}>{d} days</button>
            ))}
          </div>
          {pv.examples && pv.examples.length > 0 && (
            <details className="mt-2 text-xs text-fog-dim">
              <summary className="cursor-pointer">Preview: {pv.file_count?.toLocaleString()} files, {fmtBytes(pv.total_bytes ?? 0)}</summary>
              <ul className="mt-1 space-y-0.5">
                {pv.examples.map((f) => (<li key={f.path} className="flex justify-between gap-2"><span className="truncate" title={f.path}>{f.path}</span><span>{fmtBytes(f.size)}</span></li>))}
              </ul>
            </details>
          )}
        </>
      )}

      {memory && pv.candidates && (
        <div className="mt-2 space-y-1" role="radiogroup" aria-label="Application to close">
          {pv.candidates.map((c) => {
            const sel = c.pid === pv.selected?.pid;
            return (
              <button key={c.pid} role="radio" aria-checked={sel} disabled={busy} onClick={() => !sel && onPropose("close_application", { pid: c.pid })}
                className={`flex w-full items-center justify-between rounded-lg px-3 py-1.5 text-left text-xs ${sel ? "bg-companion/20 ring-1 ring-companion" : "bg-ink-700 hover:bg-ink-600"}`}>
                <span>{c.display_name}</span><span className="text-fog-dim">{c.memory_mb.toLocaleString()} MB</span>
              </button>
            );
          })}
        </div>
      )}

      <p className="mt-2 text-xs text-warn">{pv.risk}</p>
      <div className="mt-3 flex gap-2">
        <button onClick={onApprove} disabled={busy} className="flex-1 rounded-lg bg-good px-3 py-2 text-sm font-semibold text-ink-950 hover:brightness-110 disabled:opacity-50">
          {memory ? `Approve: close ${pv.selected?.display_name.replace(" (simulated)", "") ?? "app"}` : "Approve cleanup"}
        </button>
        <button onClick={onReject} disabled={busy} className="rounded-lg border border-ink-600 px-4 py-2 text-sm hover:bg-ink-700 disabled:opacity-50">Reject</button>
      </div>
    </div>
  );
}
