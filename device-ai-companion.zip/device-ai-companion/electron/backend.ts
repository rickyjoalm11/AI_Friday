import { ChildProcess, spawn, execFile } from "child_process";
import crypto from "crypto";
import { app } from "electron";
import net from "net";
import path from "path";

export interface BackendInfo { baseUrl: string; wsUrl: string; token: string }

function freePort(): Promise<number> {
  return new Promise((resolve, reject) => {
    const srv = net.createServer();
    srv.once("error", reject);
    srv.listen(0, "127.0.0.1", () => {
      const port = (srv.address() as net.AddressInfo).port;
      srv.close(() => resolve(port));
    });
  });
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** Starts the Python backend as a child process (packaged .exe in production) and stops it cleanly. */
export class BackendProcess {
  private child: ChildProcess | null = null;
  private exited = false;
  private stderrTail = "";
  info!: BackendInfo;

  async start(): Promise<BackendInfo> {
    const port = await freePort();
    const token = crypto.randomBytes(24).toString("hex");
    const env = {
      ...process.env,
      DAC_PORT: String(port),
      DAC_HOST: "127.0.0.1",
      DAC_TOKEN: token,
      DAC_DATA_DIR: app.getPath("userData"),
      DAC_PARENT_PID: String(process.pid),
      PYTHONUNBUFFERED: "1",
      PYTHONIOENCODING: "utf-8",
    };
    if (app.isPackaged) {
      const exe = path.join(process.resourcesPath, "backend", "dac-backend.exe");
      this.child = spawn(exe, [], { env, windowsHide: true });
    } else {
      const python = process.env.DAC_PYTHON || (process.platform === "win32" ? "python" : "python3");
      this.child = spawn(python, ["run_backend.py"], { env, cwd: path.join(__dirname, ".."), windowsHide: true });
    }
    this.child.stderr?.on("data", (d) => { this.stderrTail = (this.stderrTail + d.toString()).slice(-1500); });
    this.child.on("exit", () => { this.exited = true; });
    this.child.on("error", (e) => { this.stderrTail += `\n${e.message}`; this.exited = true; });

    const baseUrl = `http://127.0.0.1:${port}`;
    this.info = { baseUrl, wsUrl: `ws://127.0.0.1:${port}/ws?token=${token}`, token };

    const deadline = Date.now() + 90_000; // first launch of a PyInstaller exe can be slow (antivirus scan)
    while (Date.now() < deadline) {
      if (this.exited) throw new Error(`The backend stopped unexpectedly.\n\n${this.stderrTail.trim()}`);
      try {
        const r = await fetch(`${baseUrl}/api/health`);
        if (r.ok && (await r.json()).ready) return this.info;
      } catch { /* not up yet */ }
      await sleep(300);
    }
    throw new Error("The backend did not become ready in time.");
  }

  async stop(): Promise<void> {
    const child = this.child;
    if (!child || this.exited) return;
    try {
      await fetch(`${this.info.baseUrl}/api/shutdown`, {
        method: "POST", headers: { Authorization: `Bearer ${this.info.token}` }, signal: AbortSignal.timeout(2000),
      });
    } catch { /* fall through to forced stop */ }
    for (let i = 0; i < 20 && !this.exited; i++) await sleep(250);
    if (!this.exited && child.pid) {
      if (process.platform === "win32") {
        await new Promise<void>((res) => execFile("taskkill", ["/pid", String(child.pid), "/T", "/F"], () => res()));
      } else child.kill("SIGKILL");
    }
  }
}
