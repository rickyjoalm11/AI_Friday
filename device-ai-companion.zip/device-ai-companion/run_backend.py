"""Entry point for development (python run_backend.py) and for PyInstaller."""
import os

import uvicorn

from backend.main import app, check_startup_security


def main():
    check_startup_security()
    host = os.environ.get("DAC_HOST", "127.0.0.1")
    port = int(os.environ.get("DAC_PORT", "8765"))
    if not os.environ.get("DAC_TOKEN"):
        print("WARNING: DAC_TOKEN not set — API auth is disabled (loopback only).", flush=True)
    server = uvicorn.Server(uvicorn.Config(app, host=host, port=port, log_level="warning"))
    app.state.server = server
    server.run()


if __name__ == "__main__":
    main()
